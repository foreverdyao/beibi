window.uicreat = async function() {
	//mainjs是初始化服务完成后调用  会初始化大量东西 造成长时间白屏  建议ui相关代码放在此函数里面
	//注意  这个函数执行的时候 android服务并没有初始化完成,请不要使用android api  只建议写ui逻辑
	accui.resetui();
	accui.creat_title("远程连接基座");
	accui.creat_input("id2", "ip:", "请输入ip/局域网或公网", "");
	accui.creat_input("id3", "端口:", "输入端口9006", "");
	accui.creat_btn("id5", "链接", 链接); //null改为点击回调函数;


}


window.mainjs = async function() {
	//<-------下面是远程调试相关,打包请去掉--------->
	//android.hbuiderxzs.getsever();
	//<-------上面是远程调试相关,打包请去掉--------->
	//android.hbuiderxzs.getsever();

	log("我是开机启动函数");
	var str = plus.storage.getItem("ip");
	if (str != "" || str != null) {
		accui.set_input_txt("id2", str)
	}
	var str = plus.storage.getItem("port");
	if (str != "" || str != null) {
		accui.set_input_txt("id3", str)
	}
	判断并打开截图权限()
	链接()

}

function 判断并打开截图权限() {
	var str = screen.isopen()
	if (str) {
		app.toast("有截图权限了")
	} else {
		app.toast("申请截图权限")
		var isok = mon.getscreen();
		log(isok)
		if (isok) {
			log("申请截图权限")
			app.toast("申请截图权限")
		} else {
			log("截图权限申请失败")
			app.toast("截图权限申请失败")
		}
	}

}

function 链接() {

	var ip, port
	ip = accui.get_input("id2")
	port = accui.get_input("id3")
	if (ip != "" && port != "") {
		plus.storage.setItem("ip", ip);
		plus.storage.setItem("port", port);
		tcpzs.connect(ip, Number(port))

	}

}

tcpzs.onconnect = async function(data) {
	log("tcp连接成功了。。。")
	app.toast("tcp连接成功了")
	sleep(2000)
	var r = {};
	r.text = "立即开始";
	var node = acc.findview(r);
	if (node) {
		log("找到了")
		node.clickEX()
	} else {
		log("没找到这个节点")
	}
	
	
}

tcpzs.onclose = async function(data) {
	log("tcp断开了..尝试重新连接")
	链接()
}


				



