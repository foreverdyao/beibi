
function ises6() {
	
	function loadx5() {
		var div = document.createElement('div');
		div.style =
			"height: 15%; width: 90%; position: fixed;margin: auto;left: 0;right: 0;top: 0;bottom: 0;background-color: darkgrey;"
		div.innerHTML =
			'<div  style="text-align: center;"> 加载X5内核中请稍后,如果是模拟器,请升级,仅限真机支持X5;您也可以选择打包时勾选编译ES5语法,就能支持安卓5.0的模拟器了</div><div id="updatestate" style="text-align: center;margin-left:5%; width: 0%;background-color: darkturquoise;">0%</div>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);
		setTimeout(function() {
			File = plus.android.import('java.io.File');
			activity = plus.android.runtimeMainActivity();

			f = new File("sdcard/Tencent/tbs/backup/" + activity.getPackageName() + "/x5.tbs.org")
			if ((new Date() - f.lastModified()) < 100000) {
				alert("x5内核加载成功,请强制结束应用重新打开")
			}

		}, 3000);
	}
	try {
		eval("async function aaaaa(){};");
		return true;
	} catch (e) {
		setTimeout(function() {
			loadx5();
		}, 3000);
		return false;
	}

}

ises6()
