window.jsmode = "es6"
window.errstr = "";
window.addEventListener("unhandledrejection", async function(event) {
	try {
		window.floatw = android.floatwindow;
		floatw.showlog(true);

		let arr = event.reason.stack.split(/\r?\n/);
		for (var i = 1; i < arr.length; i++) {
			var value = arr[arr.length - i];
			try {
				var stack = {
					at: null,
					file: null,

				};
				try {
					stack.at = value.match(/at(.*?)\(/)[1];
				} catch (e) {
					stack.at = "";
					//TODO handle the exception
				}

				try {
					let temarr = value.split("/");
					stack.file = temarr[temarr.length - 1];
				} catch (e) {
					stack.file = "";
					//TODO handle the exception
				}
				floatw.addlog("错误函数:" + stack.at);
				floatw.addlog("所在文件:" + stack.file);
			} catch (e) {}
		}
		let msg = event.reason.message;
		var jg = msg.match(/(.*?)is not defined/);
		if (jg) {
			msg = jg[1] + "不是一个存在的值";
		}
		var jg = msg.match(/Cannot read property(.*?)of null/);
		if (jg) {
			msg = "不能对空对象null取值" + jg[1];
		}
		var jg = msg.match(/(.*?)is not a function/);
		if (jg) {
			msg = jg[1] + "不是一个函数";
		}
		floatw.addlog(msg);
		floatw.addlog("js代码执行错误");

		android.log.err(event.reason);

	} catch (e) {
		//TODO handle the exception
		console.log(e);
	}

});


window.addEventListener('error', async function(eventErr) {
	try {
		errstr = errstr + "js代码加载错误:</br>";
		errstr = errstr + eventErr.message + "</br>";
		errstr = errstr + "路径:" + "</br>";
		errstr = errstr + eventErr.filename + "</br>";
		errstr = errstr + "行:";
		errstr = errstr + eventErr.lineno + "</br></br></br>";
		android.log.err(event);
	} catch (e) {
		console.log(e);
		//TODO handle the exception
	}
	document.write(errstr)
});


function sleepold(ms) {
	return new Promise(function(resolve, reject) {
		setTimeout(resolve, ms);
	})
}
async function sleep(ms) {
	let begint=new Date();
	while(true){
		if(new Date()-begint>ms){
			break;
		}
		await sleepold(10);
	}	
}

function ises6() {
	if (jsmode == "es5") {
		return true;
	}

	function loadx5() {
		var div = document.createElement('div');
		div.style =
			"height: 15%; width: 90%; position: fixed;margin: auto;left: 0;right: 0;top: 0;bottom: 0;background-color: darkgrey;"
		div.innerHTML =
			'<div  style="text-align: center;"> 加载X5内核中请稍后,如果是模拟器,请升级,仅限真机支持X5;您也可以选择打包时勾选编译ES5语法,就能支持安卓5.0的模拟器了</div><div id="updatestate" style="text-align: center;margin-left:5%; width: 0%;background-color: darkturquoise;">0%</div>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);
		setTimeout(function() {
			File = plus.android.import('java.io.File');
			activity = plus.android.runtimeMainActivity();

			f = new File("sdcard/Tencent/tbs/backup/" + activity.getPackageName() + "/x5.tbs.org")
			if ((new Date() - f.lastModified()) < 100000) {
				alert("x5内核加载成功,请强制结束应用重新打开")
			}

		}, 3000);
	}
	try {
		eval("async function aaaaa(){};");
		return true;
	} catch (e) {
		setTimeout(function() {
			loadx5();
		}, 3000);
		return false;
	}
}


async function onplusready() {
	if (ises6() == false) {
		return;
	}
	var first = null;
	plus.key.addEventListener('backbutton', function() {
		var webview = plus.webview.currentWebview();
		webview.canBack(function(e) {
			if (e.canBack) {
				webview.back(); //这里不建议修改自己跳转的路径  
			} else {
				//首次按键，提示‘再按一次退出应用’  
				if (!first) {
					first = new Date().getTime(); //获取第一次点击的时间戳  
					// console.log('再按一次退出应用');//用自定义toast提示最好  
					// toast('双击返回键退出应用'); //调用自己写的吐丝提示 函数  
					plus.nativeUI.toast("再按一次退出本应用", {
						duration: 'short'
					}); //通过H5+ API 调用Android 上的toast 提示框  
					setTimeout(function() {
						first = null;
					}, 1000);
				} else {
					if (new Date().getTime() - first < 1000) { //获取第二次点击的时间戳, 两次之差 小于 1000ms 说明1s点击了两次,  
						plus.runtime.quit();
					}
				}
			}
		})
	});

	for (var i = 0; i < 10; i++) {
		await sleep(10);
		console.log(1111);
		plus.bridge.execSync("androidclass", "starandroid");
		for (var i2 = 0; i2 < 10; i2++) {
			await sleep(100);
			if (android.sdkversion) {
				return;
			}
		}
	}
}
window.onload = async function() {
	if (window.plus) {
		onplusready();
	} else {
		document.addEventListener("plusready", async function() {
			onplusready();
		}, false);
	}
}
