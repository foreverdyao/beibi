/**
 * @description  h5方案 兼容 ios
 */
window.plush5 = {
	xhr: {
		get: async function(url, header, timeout) {
			var xhr = new plus.net.XMLHttpRequest();
			
			if (!timeout) {
				timeout = 30000;
			}
			xhr.timeout = timeout;
			xhr.open("GET", url);
			for (key in header) {
				xhr.setRequestHeader(key, header[key]);
			}
			xhr.send();
			while (true) {
				if (xhr.readyState == 4) {
					break;
				}
				await sleep(10);
			}
			return xhr.responseText;
		},
		post: async function(url, header, body, timeout) {
			var xhr = new plus.net.XMLHttpRequest();
			if (!timeout) {
				timeout = 30000;
			}
			xhr.timeout = timeout;
			xhr.open("POST", url);
			if (typeof(body) == "object") {
				xhr.setRequestHeader("Content-Type", "application/json");
			}
			if (typeof(body) == "string") {
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			}
		
			if(header&&header.hasOwnProperty("User-Agent")){
				xhr.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0");
			}

			for (key in header) {
				xhr.setRequestHeader(key, header[key]);
			}
			if (typeof(body) == "object") {
				xhr.send(JSON.stringify(body));
			} else {
				xhr.send(body);
			}


			while (true) {
				if (xhr.readyState == 4) {
					break;
				}
				await sleep(10);
			}
			return xhr.responseText;
		},
	},

	/**
	 * @description 通讯录对象
	 */
	contacts: {
		className: null,
		/**
		 * @description 获取服务和权限
		 * @return {逻辑型} 
		 */
		getsever: async function() {
			if (mon.getphone()) {
				this.className = await new Promise(
					function(resolve, reject) {
						plus.contacts.getAddressBook(plus.contacts.ADDRESSBOOK_PHONE, function(addressbook) {

							resolve(addressbook)
						}, function(e) {
							resolve(null);
						});
					}
				);
				if (this.className == null) {
					return false;
				}

				return true;
			}

			return false;
		},
		/**
		 * @param {Object} name 用户名
		 * @param {Object} phone 手机号
		 * @description 添加 手机号
		 * @return {逻辑型}
		 */
		add: function(name, phone) {
			var contact = this.className.create();
			contact.name = {
				givenName: name
			};
			contact.phoneNumbers = [{
				type: "手机",
				value: phone,
				preferred: true
			}];

			return contact.save();

		},
		/**
		 * @param {整数} index  索引
		 * @description 获取单个联系人 
		 * @return {json}  成功返回json对象,失败 返回null
		 */
		getphone: async function(index) {
			var clazz = this.className;
			phone = async function(clazz) {
				return await new Promise(
					function(resolve, reject) {

						var contact = clazz.find(null, function(contacts) {
								resolve(contacts);

							},
							function(e) {
								resolve(null);
							}, {
								filter: [{
									logic: "and",
									field: "id",
									value: index
								}],
								multi: false
							});


					}
				);
			}
			var json = await phone(clazz);
			if (json) {
				if (json.length > 0) {
					var phone = {};
					phone.name = json[0].displayName;
					phone.phone = json[0].phoneNumbers[0].value;
					return phone;
				}
			}
			return null;

		},
		/**
		 * @description 获取所有联系人 
		 * @return {jsonarr}  成功返回json对象数组,失败 返回null
		 */
		getphones: async function() {
			var clazz = this.className;
			phone = async function(clazz) {
				return await new Promise(
					function(resolve, reject) {

						var contact = clazz.find(null, function(contacts) {
								resolve(contacts);

							},
							function(e) {
								resolve(null);
							}, {

								multi: false
							});


					}
				);
			}
			var json = await phone(clazz);
			if (json) {
				var phonearr = Array();

				for (var i = 0; i < json.length; i++) {
					var phone = {};
					phone.name = json[i].displayName;
					phone.phone = json[i].phoneNumbers[0].value;
					phonearr[i] = phone;
				}

				return phone;

			}
			return null;

		},

		/**
		 * @description  获取通讯录联系人数量
		 * @return {整数} 成功 返回数量 失败返回null
		 */
		getcount: async function() {
			var clazz = this.className;
			phone = async function(clazz) {
				return await new Promise(
					function(resolve, reject) {
						var contact = clazz.find(null, function(contacts) {
								resolve(contacts.length);
							},
							function(e) {
								resolve(null);
							}, {
								multiple: true
							});


					}
				);
			}
			return await phone(clazz);
		},
		/**
		 * @description 清空通讯录
		 * @return {逻辑型} 成功返回true   失败返回false
		 */
		delall: async function() {
			var clazz = this.className;
			phone = async function(clazz) {
				return await new Promise(
					function(resolve, reject) {
						var contact = clazz.find(null, function(contacts) {
								for (var i = 0; i < contacts.length; i++) {
									contacts[i].remove(null, null);

								}
								resolve(true);
							},
							function(e) {
								resolve(false);
							}, {
								multiple: true
							});


					}
				);
			}
			return await phone(clazz);
		},
		/**
		 * @param {Object} index 索引
		 * @description 删除指定 手机号
		 * @return {逻辑型} 成功返回true   失败返回false
		 */

		del: async function(index) {
			var clazz = this.className;
			phone = async function(clazz) {
				return await new Promise(
					function(resolve, reject) {

						var contact = clazz.find(null, function(contacts) {
								for (var i = 0; i < contacts.length; i++) {
									contacts[i].remove(null, null);

								}

								resolve(true);

							},
							function(e) {
								resolve(null);
							}, {
								filter: [{
									logic: "and",
									field: "id",
									value: index
								}],
								multi: false
							});


					}
				);
			}
			return await phone(clazz);
		}
	},
}
