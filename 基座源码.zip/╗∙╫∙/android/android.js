window.android = {
	jssdk: "2021年4月10日 17:38:11",
	yiyuyan: "2021年1月31日 21:34:55",
	/**
	 * @description 资源文件路径
	 */
	path: null,
	/**
	 * @description sdk版本号
	 */
	sdkversion: null,
	/**
	 * @description  本app的activity
	 */
	activity: null,
	/**
	 * @description  已经加载完毕的安卓类
	 */
	className: {
		Path: null, //手势类 android.graphics.Path
		File: null, // 文件类 java.io.File
	},
	/**
	 * @description 通讯录对象
	 */
	contacts: plush5.contacts,
	mysql: {
		connect: function(host, port, use, pwd, dbname) {
			return this.className.connect(host, port, use, pwd, dbname);
		},
		query: function(sql) {
			return this.className.query(sql);
		},
		execute: function(sql) {
			return this.className.execute(sql);
		}
	},
	zip: {
		tozip: function(dirname, zipname) {
			return this.className.tozip(dirname, zipname)
		},
		tozipone: function(dirname, zipname) {
			return this.className.tozipone(dirname, zipname)
		},
		unzip: function(zipname, dirname) {
			return this.className.unzip(zipname, dirname)
		},
	},
	ocr: {
		/**
		 * @description  初始化服务
		 * @return {bool}
		 */
		getsever: async function() {
			var applist = android.global.getapplist();
			if (applist.indexOf(',"packageName":"cn.webrebot.ocr"') == -1) {
				android.global.toast("正在下载ocr识别模块");
				var dtask = plus.downloader.createDownload(
					"https://word.xinhuoshuju.com/acc/acczs/unpackage/ACC_OCR%E6%A8%A1%E5%9D%97.apk");
				dtask.start();
				for (var i = 0; i < 1999; i++) {
					if (dtask.state == 4) {
						plus.runtime.install(dtask.filename)
						try {
							var node = await android.AccessibilityService.findviewEX({
								"text": "安装"
							}, 3000);
							node.click();
							var node = await android.AccessibilityService.findviewEX({
								"text": "完成"
							}, 3000);
							node.click();
							return await this.getsever();
						} catch (e) {
							log(e)
							return false;
							//TODO handle the exception
						}
						break;
					}
					await sleep(100)
				}
				return false;
			}
			var isbind = this.className.getsever();
			await sleep(1000)
			if (!isbind) {
				android.global.toast("启动ocr服务失败,建议打开说有权限");
				log("ocr初始化失败", "解决方法: 百度 :手机型号+打开关联启动")
				return false;
			}
			if (!this.className.init()) {
				try {
					var node = await android.AccessibilityService.findviewEX({
						"text": "允许"
					}, 3000);
					node.click();
				} catch (e) {
					//TODO handle the exception
				}
				android.global.toast("启动ocr服务失败,建议打开说有权限");
				return false;
			} else {
				return true;
			}
		},
		zcsh初始化: async function() {
			return this.getsever();
		},
		/**
		 * @description 识别指定图片
		 * @param {Object} img 图片对象
		 * @return {jsonstr}
		 */
		ocrimg: function(img) {
			var rstr = this.className.ocrimg(img.id);
			if (rstr == null) {
				this.getsever();
			}
			return rstr;
		},
		zsbzdtp识别指定图片: function(img) {
			return this.ocrimg(img);
		},
		/**
		 * @description  识别当前屏幕
		 * @return {jsonstr}
		 */
		ocr: function() {
			var rstr = this.className.ocr();
			if (rstr == null) {
				this.getsever();
			}
			return rstr;
		},
		zsbdqpm识别当前屏幕: function() {
			return this.ocr();
		},
		/**
		 * @description 识别指定范围
		 * @param {Object} x 
		 * @param {Object} y
		 * @param {Object} x2
		 * @param {Object} y2
		 * @return {jsonstr}
		 */
		ocrarea: function(x, y, x2, y2) {
			var rstr = this.className.ocrarea(x, y, x2, y2);
			if (rstr == null) {
				this.getsever();
			}
			return rstr;
		},
		zsbzdfw识别指定范围: function(x, y, x2, y2) {
			return this.ocrarea(x, y, x2, y2);
		},

	},
	screen: {
		isopen: function() {
			window.addEventListener('orientationchange', function() {
				android.screen.resetscreen();
			}, false);
			var mactivity = plus.android.runtimeMainActivity();
			mactivity.onActivityResult = function(requestCode, resultCode, data) {
				android.screen.getpermissionok(requestCode, resultCode, data);
			}
			return this.className.getpermission(mactivity);
		},
		getpermissionok: function(requestCode, resultCode, data) {
			return this.className.getpermissionok(requestCode, resultCode, data);
		},
		/**
		 * @description  base64转img对象
		 * @param {type} str base64字符串 
		 * @return {javascriptbitmap}
		 */
		base64toimg: function(str) {
			var imgid = this.className.base64toimg(str);
			if (imgid == -1) {
				return null;
			}
			return new javascriptbitmap(imgid, this.className);
		},


		/**
		 * @description  获取截图
		 * @return {javascriptbitmap}
		 */
		getimg: function() {
			//var imgid = this.className.getimg();
			return new javascriptbitmap(0, this.className);
		},
		zhqjt获取截图: function() {
			//var imgid = this.className.getimg();
			return this.getimg();
		},

		/**
		 * @description 区域截图
		 * @param {Object} x 起始点x
		 * @param {Object} y 起始点y
		 * @param {Object} w 宽度
		 * @param {Object} h 高度
		 */
		getareaimg: function(x, y, w, h) {
			return this.getimg().getareaimg(x, y, w, h);
		},
		zqyjt区域截图: function(x, y, w, h) {
			return this.getareaimg(x, y, w, h);
		},
		/**
		 * @description  单点找色
		 * @param {Object} x 坐标
		 * @param {Object} y  坐标
		 * @param {Object} x2 坐标
		 * @param {Object} y2 坐标
		 * @param {Object} colorstr 颜色 描述
		 * @return {intarr} 坐标数组
		 */
		findcolor: function(x, y, x2, y2, colorstr) {
			return this.getimg().findcolor(x, y, x2, y2, colorstr);
		},
		/**
		 * @description  多点找色
		 * @param {Object} x 坐标
		 * @param {Object} y  坐标
		 * @param {Object} x2 坐标
		 * @param {Object} y2 坐标
		 * @param {Object} colorstr 颜色 描述
		 * @param {qua} 相似度
		 * @return {intarr} 坐标数组
		 */
		findcolors: function(x, y, x2, y2, qua, colorstr) {
			return this.getimg().findcolors(x, y, x2, y2, qua, colorstr);
		},
		/**
		 * @description  单点比色
		 * @param {Object} x 坐标
		 * @param {Object} y  坐标
		 * @param {Object} colorstr 颜色 描述
		 * @return {bool} true false
		 */
		iscolor: function(x, y, colorstr) {
			return this.getimg().iscolor(x, y, colorstr);
		},
		/**
		 * @description  多点找色颜色坐标固定
		 * @param {Object} x 坐标
		 * @param {Object} y  坐标
		 * @param {Object} x2 坐标
		 * @param {Object} y2 坐标
		 * @param {Object} colorstr 颜色 描述
		 * @return {intarr} 坐标数组
		 */
		iscolors: function(colorstr, qua) {
			return this.getimg().iscolors(colorstr, qua);
		},
		zddzs单点找色: function(x, y, x2, y2, colorstr) {
			return this.findcolor(x, y, x2, y2, colorstr);
		},
		/**
		 *@description  获取指定点颜色
		 * @param {Object} x 获取指定点颜色
		 * @param {Object} y 获取指定点颜色
		 */
		getcolor: function(x, y) {
			return this.getimg().getcolor(x, y);
		},
		zqzddys取指定点颜色: function(x, y) {
			return this.getcolor(x, y);
		},
		/**
		 * @description 重置截屏服务 ,如果屏幕方向 变化  请调用此方法重置
		 */
		resetscreen: function() {
			return this.className.resetscreen();
		},

	},
	/**
	 * @description 短信
	 */
	sms: {
		/**
		 * @description 获取短信
		 * @param {int} index  条数
		 * @return {josn} json字符串
		 */
		getsms: function(index) {
			return this.className.getSms(index);
		},
		zhqdx获取短信: function(index) {
			return this.className.getSms(index);
		},
	},
	/**
	 * @description hbuiderx插件连接
	 */
	hbuiderxzs: {
		className: null,
		isok: false,
		setudp: function(issend) {
			this.className.setudp(issend);
		},
		getsever: function() {
			android.log.ishbuider = true;
			window.log = android.log.log;
			window.err = android.log.err;
		},
		connect: function(ip, port) {
			this.className.selfconnect();
			this.className.connect(ip, port)
		},
		close: function() {
			this.className.close();
			this.log.ishbuider = false;
		}
	},
	log: {
		istcp: false,
		ishbuider: false,
		log: function() {
			let text = "";
			var len = arguments.length;
			for (var i = 0; i < len; i++) {
				let pobj = arguments[i];
				var str = "";
				var lx = "";
				switch (Object.prototype.toString.call(pobj)) {
					case "[object Promise]":
						str = "异步函数,请用await接收";
						lx = "[object Promise]";
						break;
					case "[object AsyncFunction]":
						str = "异步函数";
						lx = "[AsyncFunction]";
						break;
					case "[object Number]":
						str = pobj;
						lx = "[Number]";
						break;
					case "[object String]":
						str = pobj;
						lx = "[String]";
						break;
					case "[object Object]":
						str = JSON.stringify(pobj);
						lx = "[String]";
						break;
					case "[object Null]":
						str = "null";
						lx = "";
						break;
					case "[object Undefined]":
						str = "undefined";
						lx = "";
						break;
					case "[object Function]":
						str = "一个函数";
						lx = "";
						break;
					default:
						str = pobj;
						lx = Object.prototype.toString.call(pobj);
						break;
				}
				text = text + str + " " + lx + " , ";

			}
			var str = new Error().stack;
			var arr = str.split(/\r?\n/);
			var stackarr = [];
			for (var i = 0; i < arr.length; i++) {
				var value = arr[i];
				try {
					var stack = {
						at: null,
						file: null,
						line: null
					};
					try {
						stack.at = value.match(/at(.*?)\(/)[1];
					} catch (e) {
						stack.at = "";
						//TODO handle the exception
					}
					stack.file = value.match(/www\/(.*?)\:/)[1];
					stack.file = stack.file.replace("/debug/", "/");
					stack.line = value.match(/(js|html):(.*?):/)[2];
					if (stackarr.length > 0) {
						if (stack.file == stackarr[stackarr.length - 1].file && stack.line == stackarr[stackarr
								.length - 1].line)
							continue;
					}
					stackarr.push(stack);
				} catch (e) {}
			}
			var obj = {
				fun: "log",
				data: {
					text: text,
					stack: stackarr
				}
			};
			str = JSON.stringify(obj);
			if (android.log.ishbuider) {
				for (var i = 0; i < Math.ceil(str.length / 1000); i++) {
					android.hbuiderxzs.className.setlog(str.substring(i * 1000, i * 1000 + 1000));
				}
				android.hbuiderxzs.className.sendlog();
			}
		},
		err: function(e) {
			if (this.ishbuider == false) {
				console.log(e);
				return;
			}
			var str = e.stack;
			var stackarr = [];
			try {
				console.log(str);
				var arr = str.split(/\r?\n/);
				for (var i = 0; i < arr.length; i++) {
					var value = arr[i];
					try {
						var stack = {
							at: null,
							file: null,
							line: null
						};
						try {
							stack.at = value.match(/at(.*?)\(/)[1];
						} catch (e) {
							stack.at = "";
							//TODO handle the exception
						}
						stack.file = value.match(/www\/(.*?)\:/)[1];
						stack.file = stack.file.replace("/debug/", "/");
						stack.line = value.match(/(js|html):(.*?):/)[2];
						if (stackarr.length > 0) {
							if (stack.file == stackarr[stackarr.length - 1].file && stack.line == stackarr[
									stackarr.length - 1].line)
								continue;
						}
						stackarr.push(stack);
					} catch (e) {}
				}
			} catch (e) {
				//TODO handle the exception
			}
			var obj = {
				fun: "logerr",
				data: {
					text: "执行错误:" + e,
					stack: stackarr
				}
			};
			str = JSON.stringify(obj);
			for (var i = 0; i < Math.ceil(str.length / 1000); i++) {
				android.hbuiderxzs.className.setlog(str.substring(i * 1000, i * 1000 + 1000));
			}
			android.hbuiderxzs.className.sendlog();
		}
	},
	http: {
		/**
		 * @description  获取服务对象
		 */
		getsever: function() {},
		/**
		 * @param {url} url url地址
		 * @param {header} header 协议头
		 * @description  发送get请求
		 * @return {json}  返回响应结果
		 */
		get: function(url, header) {
			if (header != null) {
				header = JSON.stringify(header);
			}
			return this.className.get(url, header);
		},
		/**
		 * @param {Object} url url地址
		 * @param {Object} body 发送的数据
		 * @param {Object} header 协议头
		 * @description 发送 post请求 
		 * @return {json} 响应结果
		 */
		post: function(url, body, header) {
			if (header != null) {
				header = JSON.stringify(header);
			}
			return this.className.post(url, body, header);
		}
	},
	loaddex: {
		/**
		 * @description 初始化服务
		 */
		getsever: function() {},
		/**
		 * @description 加载dex文件
		 * @param {Object} path 文件路径
		 * @return {dex} dex对象
		 */
		loaddex: function(path) {
			return this.className.loaddex(path);
		},
		/**
		 * @description  加载dex的类
		 * @param {Object} dex dex对象
		 * @param {Object} pgname 需要加载的类名 类似于 import
		 * @return {class} 类名
		 */
		loadclass: function(dex, pgname) {
			return this.className.loadclazz(dex, pgname);
		},
		/**
		 * @param {Object} clazz class对象
		 * @param {Object} fun 要 执行的方法
		 * @param {Object} args 参数
		 */
		execution: function(clazz, fun, classarr, objarr) {
			return this.className.execution(clazz, fun, classarr, objarr);
		},
		/**
		 * @description 获取int的class
		 */
		getintclass: function() {
			return this.className.getintclass();
		},
	},
	device: {},
	shell: {
		getsever: function() {},
		haveRoot: function() {
			return this.className.haveRoot();
		},
		shell: function(cmd) {
			return this.className.execRootCmdSilent(cmd);
		},
		shellstr: function(cmd) {
			return this.className.execRootCmd(cmd);
		},
	},
	floatwindow: {
		getsever: function() {
			return this.className.getsever();
		},
		isopen: function() {
			return this.className.isopen();
		},
		openseting: function() {
			return this.className.openseting()
		},
		star: function() {
			return this.className.star();
		},
		/**
		 * @param {int} id  按钮id 
		 * @param {str} name 按钮显示名字
		 */
		addselfbt: function(id, name) {
			if (typeof(id) == "number") {
				return this.className.addselfbt(name, id);
			} else {
				return this.className.addselfbt(id, name);
			}
		},
		ztjzdyan添加自定义按钮: function(id, name) {
			return this.addselfbt(id, name);
		},
		/**
		 * @param {文本} str 日志悬浮窗添加文字
		 */
		addlog: function(str) {
			return this.className.addlog(str + "");
		},
		ztjrz添加日志: function(str) {
			return this.addlog(str);
		},
		/**
		 * @description  修改悬浮窗位置
		 * @param {Object} x 日志悬浮窗x坐标
		 * @param {Object} y 日志悬浮窗y坐标
		 * @param {Object} w 日志悬浮窗宽度
		 * @param {Object} h 日志悬浮窗高度
		 */
		setlogxy: function(x, y, w, h) {
			return this.className.setlogxy(x, y, w, h);
		},
		zszxfcwz悬浮窗位置: function(x, y, w, h) {
			return this.setlogxy(x, y, w, h);
		},
		/**
		 * @param {html} str
		 * @description 设置悬浮窗文本 html
		 */
		addloghtml: function(str) {
			return this.className.addloghtml(str);
		},
		zszxfc设置悬浮窗h5: function(str) {
			return this.addloghtml(str);
		},
		onclick: async function(data) {
			return true;
		},
		/**
		 * @description 是否显示日志
		 * @param {Object} show 是否显示
		 */
		showlog: function(show) {
			return this.className.showlog(show);
		},
		zrzsfxs日志是否显示: function(show) {
			return this.showlog(show);
		},
		/**
		 * @description  是否显示悬浮窗按钮
		 * @param {bool} show 是否显示
		 */
		showArrow: function(show) {
			return this.className.showArrow(show);
		},
		zansfxs按钮是否显示: function(show) {
			return this.showArrow(show);
		},
		/**
		 * @description  更改悬浮窗文字
		 * @param {int} id  悬浮窗id
		 * @param {str} str 文本
		 */
		settext: function(id, str) {
			this.className.settext(id, str);
		},
		zszanwz设置按钮文字: function(id, str) {
			this.settext(id, str);
		},
		/**
		 * @description  设置悬浮窗指定按钮是否显示
		 * @param {int} id 按钮id
		 * @param {bool} show 是否显示
		 */
		setvisible: function(id, show) {
			this.className.setvisible(id, show);
		},
		zszanxs设置按钮显示: function(id, show) {
			this.setvisible(id, show);
		}
	},
	/*
	tcp
	*/
	socket: {
		connect: function(ip, port) {
			return this.className.connet(ip, port);
		},
		sendstr: function(str, pack) {
			pack = pack || false;
			return this.className.sendstr(str, pack);
		},
		sendbytes: function(bytes) {
			return this.className.sendbytes(bytes);
		},
		sendbimp: function(bimp, pack) {
			pack = pack || false;
			return this.className.sendbimp(bimp, pack);
		},
		getstr: function() {
			return this.className.getstr();
		},
		callback: function(open, callback) {
			var backname = "socket" + new Date().getTime();
			eval("window.callback." + backname + "=" + callback)
			return this.className.callback(open, backname);
		},
		closesocket: function() {
			return this.className.closesocket();
		}
	},
	/*
	文件对象
	*/
	fie: {
		getsever: function() {},
		/**
		 * @description 读取文本
		 * @param {str} path 路径
		 * @return {str} 成功返回文本  失败返回null 
		 */
		readstr: function(path) {
			return this.className.readstr(path);
		},
		zdqwb读取文本: function(path) {
			return this.readstr(path);
		},
		/**
		 * @description 读取指定行文本
		 * @param {str} path 文件路径
		 * @param {int} index 行数 0开始
		 * @return {str} 成功返回文本 失败返回null
		 */
		readstrline: function(path, index) {
			return this.className.readstrline(path, index);
		},
		zdqwbh读取文本行: function(path, index) {
			return this.readstrline(path, index);
		},
		/**
		 * @description 读取行文本为数组
		 * @param {str} path 文件路径
		 * @return {strarr} 成功返回文本 失败返回null
		 */
		readstrlines: function(path) {
			return this.className.readstrlines(path);
		},
		zdqwbsz读取文本数组: function(path) {
			return this.readstrlines(path);
		},
		/**
		 * @param {Object} path
		 * @param {Object} bitmap
		 * @description 保存图片
		 */
		savebitmap: function(path, bitmap) {
			return this.className.savebitmap(path, bitmap);
		},
		zbctp保存图片: function(path, bitmap) {
			return this.savebitmap(path, bitmap);
		},
		/**
		 * @param {Object} path
		 * @param {Object} str
		 * @param {bool} xue 是否续写 
		 * @description 写text
		 */
		writestr: function(path, str, xue) {
			return this.className.writestr(path, str, xue);
		},
		zxrwb写入文本: function(path, str, xue) {
			return this.writestr(path, str, xue);
		},
		/**
		 * @param {Object} str
		 * @param {Object} path
		 * @description 写入base64 为文件
		 */
		writebase64: function(path, str) {
			return this.className.savebase64(path, str);
		},
		zxrbs写入base64为文件: function(path, str) {
			return this.savebase64(path, str);
		},
		/**
		 * @param {Object} path 路径
		 * @description 读取图片
		 * @return {bitmap} bitmap 图片对象
		 */
		readbitmap: function(path) {
			var id = this.className.readbitmap(path);
			if (id == -1) {
				return null;
			}
			return new javascriptbitmap(id, android.screen.className);

		},
		zdqtp读取图片: function(path) {
			return this.readbitmap(path);
		},
		/**
		 * @param {Object} path 
		 * @description 读取文件为base64
		 * @return {str} base64文本字符串
		 */
		readbase64: function(path) {
			return this.className.readbase64(path);
		},
		zdqwj读取文件为base64: function(path) {
			return this.readbase64(path);
		},
		/**
		 * @param {Object} path 目录
		 * @description 删除文件
		 */
		del: function(path) {
			return this.className.del(path);
		},
		zscwj删除文件: function(path) {
			return this.className.del(path);
		},
	},
	input: {
		/**
		 * @description 判断输入法是否打开
		 */
		isopen: function() {
			//打开输入法 返回逻辑
			return this.className.inputopen();
		},
		inputsettext: function(str) {
			//输入文本
			return this.className.inputsettext(str);
		},
		inputsetcode: function(code) {
			//输入键代码
			return this.className.inputsetcode(code);
		}
	},
	/**
	 * @description 手势
	 */
	gesture: {
		/**
		 * @description  初始化服务
		 */
		getsever: function() {},
		/**
		 * @description 按下
		 * @param {Object} 坐标x
		 * @param {Object} 坐标y
		 * @return {}无返回值
		 */
		down: function(x, y) {
			return this.className.down(x, y);
		},
		/**
		 * @description 移动到
		 * @param {Object} x 坐标x
		 * @param {Object} y 坐标y
		 */
		move: async function(x, y) {
			var returns = this.className.move(x, y);
			return returns;
		},
		/**
		 * @description  抬起
		 */
		up: function(x, y) {
			return this.className.up(x, y);
		},
		/**
		 * @description 触摸指定坐标 50毫秒左右
		 * @param {Object} x x坐标
		 * @param {Object} y y坐标
		 */
		click: function(x, y) {
			return this.className.tap(Math.trunc(x), Math.trunc(y));
		},
		/**
		 * @description 触摸指定坐标 50毫秒左右
		 * @param {Object} x x坐标
		 * @param {Object} y y坐标
		 */
		zdj点击: function(x, y) {
			return this.className.tap(Math.trunc(x), Math.trunc(y));
		},
		/**
		 * @description  长按
		 * @param {Object} x x坐标
		 * @param {Object} y y坐标
		 * @param {Object} t 持续时间
		 * @return {type} 无返回值
		 */
		langclick: function(x, y, t) {
			return this.className.langtap(Math.trunc(x), Math.trunc(y), Math.trunc(t))
		},
		/**
		 * @description  长按
		 * @param {Object} x x坐标
		 * @param {Object} y y坐标
		 * @param {Object} t 持续时间
		 * @return {type} 无返回值
		 */
		zca长按: function(x, y, t) {
			return this.className.langtap(Math.trunc(x), Math.trunc(y), Math.trunc(t))
		},
		/**
		 * @description  直线滑动
		 * @param {Object} x 开始坐标 x
		 * @param {Object} y 开始坐标y
		 * @param {Object} x1 结束坐标x
		 * @param {Object} y1 结束坐标y
		 * @param {Object} t 执行时间
		 */
		swipe: function(x, y, x1, y1, t) {

			return this.className.swipe(Math.trunc(x), Math.trunc(y), Math.trunc(x1), Math.trunc(y1), Math
				.trunc(t));
		},

		zhd滑动: function(x, y, x1, y1, t) {
			return this.className.swipe(Math.trunc(x), Math.trunc(y), Math.trunc(x1), Math.trunc(y1), Math
				.trunc(t));
		},
		/**
		 * @description 仿真滑动  随机
		 * @param {Object} x 起始点x
		 * @param {Object} y 起始点y
		 * @param {Object} x1 终点x
		 * @param {Object} y1 终点y
		 * @param {Object} start 开始按住时间
		 * @param {Object} worktime 滑动时间
		 * @param {Object} endtime 滑动结束停留时间
		 */
		swipeEX: function(x, y, x1, y1, start, worktime, endtime) {
			return this.className.swipeEX(Math.trunc(x), Math.trunc(y), Math.trunc(x1), Math.trunc(y1), Math
				.trunc(start),
				Math.trunc(worktime), Math.trunc(endtime));
		},
	},
	global: {
		/**
		 * @description 唤醒手机屏幕
		 */
		openpm: function() {
			return this.className.openpm();
		},
		zdlpm点亮屏幕: function() {
			return this.className.openpm();
		},
		/**
		 * @description  分享图片
		 * @param {Object} path 图片路径
		 * @param {Object} app app名 可空
		 * @param {Object} activity 接收的组件 可空
		 */
		share: function(path, app, activity) {
			app = app || "";
			activity = activity || "";
			return this.className.share(path, app, activity)
		},
		/**
		 * @description  分享多张图片
		 * @param {Object} path 图片路径数组
		 * @param {Object} app app名 可空
		 * @param {Object} activity 接收的组件 可空
		 */
		shares: function(paths, app, activity) {
			app = app || "";
			activity = activity || "";
			return this.className.shares(paths, app, activity)
		},


		/**
		 * @description 完全退出应用
		 */
		quit: function() {
			return this.className.quit();
		},
		ztc退出: function() {
			return this.className.quit();
		},
		/**
		 * @description  编码转换
		 * @param {Object} str  待转化的字符串
		 * @param {Object} oldchar 旧编码
		 * @param {Object} newchar 新编码
		 */
		encoder: function(str, oldchar, newchar) {
			return this.className.encoder(str, oldchar, newchar);
		},
		zbmzh编码转换: function(str, oldchar, newchar) {
			return this.className.encoder(str, oldchar, newchar);
		},
		/**
		 * @description "关闭app"
		 * @param {Object} packName
		 */
		KillApp: async function(packName) {
			this.openseting(packName);
			//本代码由易助手生成,采用严格模式,请根据项目实际情况删除部分条件
			var r = {
				textEX: '.*强.*|.*停.*|.*结.*|.*行.*',
			};
			var node = await android.AccessibilityService.findviewEX(r, 5000);
			if (node) {
				node.clickEX();
			}
			var r = {
				textEX: '.*确.*|.*定.*',
			};
			var node = await android.AccessibilityService.findviewEX(r, 5000);
			if (node) {
				node.clickEX();
			}
		},
		zgb关闭app: async function(packName) {
			return await android.global.KillApp(packName);
		},
		/**
		 * @description  打开设置界面
		 * @param {Object} pakname  包名
		 */
		openseting: function(pakname) {
			var main = plus.android.runtimeMainActivity();
			var Intent = plus.android.importClass('android.content.Intent');
			var Settings = plus.android.importClass('android.provider.Settings');
			var Uri = plus.android.importClass("android.net.Uri");
			var pkUri = Uri.fromParts('package', pakname, null);
			var intent = new Intent();
			intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
			intent.setData(pkUri);
			main.startActivity(intent);
		},
		zdksz打开设置: function(pakname) {
			return this.openseting(pakname);
		},
		openuri: function(uri) {
			var main = plus.android.runtimeMainActivity();
			var Intent = plus.android.importClass('android.content.Intent');
			var Uri = plus.android.importClass("android.net.Uri");
			var intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
			main.startActivity(intent);
		},
		getsever: function() {},
		runappEX: function(pgname, className, t) {
			return this.className.runappEX(pgname, className, t);
		},
		runapp: function(pgname, className) {
			plus.runtime.launchApplication( {pname:pgname
						,extra:{}}, function ( e ) {
							log( "Open system default browser failed: " + e.message );
					} );
			return;		
			return this.className.runapp(pgname, className);
		},
		zdk打开app: function(pgname, className) {
			return this.className.runapp(pgname, className);
		},
		toast: function(str) {
			//吐司消息
			return this.className.toast(str);
		},
		zts吐司消息: function(str) {
			//吐司消息
			return this.className.toast(str);
		},
		/**
		 * @description 是否关闭省电模式
		 */
		isperformance: function() {
			return this.className.isperformance();
		},
		zgbsd关闭省电模式: function() {
			return this.className.isperformance();
		},
		/**
		 * @param {Object} text 文本
		 * @description 设置剪贴板文本
		 */
		clipset: function(text) {
			var Context = plus.android.importClass("android.content.Context");
			var main = plus.android.runtimeMainActivity();
			var clip = main.getSystemService(Context.CLIPBOARD_SERVICE);
			plus.android.invoke(clip, "setText", text);
		},
		zszjt设置剪贴板: function(text) {
			return this.clipset();
		},
		/**
		 * @description 获取剪辑版文本
		 * @return {text} 文本
		 */
		clipget: function() {
			var Context = plus.android.importClass("android.content.Context");
			var main = plus.android.runtimeMainActivity();
			var clip = main.getSystemService(Context.CLIPBOARD_SERVICE);
			return plus.android.invoke(clip, "getText");
		},
		zhqjtb获取剪贴板: function() {
			return this.clipget();
		},
		/**
		 * @description  获取应用列表
		 * @return {json} json字符串
		 */
		getapplist: function() {
			return this.className.getapplist();
		},
		zhqapplb获取app列表: function() {
			return this.className.getapplist();
		},
	},
	res: {
		id: null,
		boundsInParent: null,
		boundsInScreen: null,
		packageName: null,
		className: null,
		text: null,
		error: null,
		maxTextLength: null,
		contentDescription: null,
		tooltipText: null,
		checkable: null,
		checked: null,
		focusable: null,
		focused: null,
		selected: null,
		clickable: null,
		longClickable: null,
		contextClickable: null,
		enabled: null,
		password: null,
		scrollable: null,
		importantForAccessibility: null,
		visible: null
	},
	AccessibilityService: {
		/**
		 * @description 执行adb
		 * @param {str} adb adb命令 
		 */
		cmd: function(adb) {
			return this.className.cmd(adb);
		},
		/**
		 * @description 发送键盘按键
		 * @param {int} key 键代码 
		 */
		sendkey: function(key) {
			return this.className.sendkey(key);
		},
		/**
		 * @description 发送键盘输入
		 * @param {int} key 键代码 
		 */
		sendtext: function(text) {
			return this.className.sendtext(text);
		},
		/**
		 * @description 执行adb
		 */
		cmd: function(adb) {
			return this.className.cmd(adb);
		},

		/**
		 * @description 判断是否打开无障碍
		 */
		isopenAccessibility: function(open) {
			try {
				return this.className.isopenAccessibility(open);
			} catch (e) {
				//TODO handle the exception
				return false;
			}
		},
		/**
		 * @description  获取根节点 返回node对象 
		 * @return {javascriptnode} node对象
		 */
		getnode: function() {
			var nodeid = this.className.getnode();
			return new javascriptnode(nodeid, this.className);
		},
		zhqgjd获取根节点: function() {
			return this.getnode();
		},
		/**
		 * @description  获取指定窗口对象 返回node对象 
		 * @param {int} index  0 物理按键 1通知栏 2 悬浮窗 3 输入法   4  窗口
		 * @return {node} node对象
		 */
		getwindownode: function(index) {
			var nodeid = this.className.getwindownode(index);
			return new javascriptnode(nodeid, this.className);
		},
		zhqzdck获取指定窗口: function(index) {
			return this.getwindownode(index);
		},
		/**
		 * @description  寻找单个节点
		 * @param {r} r 资源描述
		 * @return {javascriptnode} 找到了 返回 node对象 没找到返回null
		 */
		findview: function(r) {
			var newr = {};
			for (var key in r) {
				if (r[key] != null) {
					newr[key] = r[key];
				}
			}
			let nodeid = this.className.findview(-1, JSON.stringify(newr));
			if (nodeid) {
				return new javascriptnode(nodeid, this.className);
			} else {
				return null;
			}
		},
		zxzjd寻找节点: function(r) {
			return this.findview(r)
		},
		/**
		 * @description  寻找多个节点
		 * @param {r} r 资源描述
		 * @return {[javascriptnode]} 找到了 返回 node对象数组 没找到返回null
		 */
		findviews: function(r) {
			var newr = {};
			for (var key in r) {
				if (r[key] != null) {
					newr[key] = r[key];
				}
			}
			let nodeids = this.className.findviews(-1, JSON.stringify(newr));
			var nodes = Array();
			if (nodeids) {
				for (var i = 0; i < nodeids.length; i++) {
					var nodeid = nodeids[i];
					nodes[i] = new javascriptnode(nodeid, this.className);
				}
				return nodes;
			} else {
				return null;
			}
		},
		zxzjdsz寻找节点数组: function(r) {
			return this.findviews(r)
		},
		/**
		 * @description 通过资源id寻找节点
		 * @param {Object} resid 资源id
		 * @return {javascriptnode} node对象,失败返回null
		 */
		getnodeByResid: function(resid) {
			r = {}
			r.resid = resid;
			return acc.findview(r)
		},
		/**
		 * @description 获取兄 节点
		 * @param {Object} resid 资源id
		 * @return {javascriptnode} node对象,失败返回null
		 */
		getlastnode: function(resid) {
			var nodeid = this.className.getlastnode(resid, 1);
			if (nodeid) {
				return new javascriptnode(nodeid, this.className);
			} else {
				return null;
			}
		},
		/**
		 * @description 获取弟节点
		 * @param {Object} resid 资源id
		 * @return {javascriptnode} node对象,失败返回null
		 */
		getnextnode: function(resid) {
			var nodeid = this.className.getlastnode(resid, 2);
			if (nodeid) {
				return new javascriptnode(nodeid, this.className);
			} else {
				return null;
			}
		},
		/**
		 * @param {str} text 文本
		 * @param {int} t 持续时间
		 * @return {javascriptnode} node对象,失败返回null
		 */
		findviewBytext: async function(text, t) {
			t = t || 3000;
			var r = {
				textEX: text,
			};
			return await android.AccessibilityService.findviewEX(r, t);
		},
		zxzjd寻找节点_文字: async function(text, t) {
			t = t || 3000;
			var r = {
				textEX: text
			};
			return await android.AccessibilityService.findviewEX(r, t);
		},
		/**
		 * @param {str} des 描述
		 * @param {Object} t 持续时间
		 * @return {javascriptnode} node对象,失败返回null
		 */
		findviewBydes: async function(des, t) {
			t = t || 3000;
			var r = {
				contentDescriptionEX: des
			};
			return await android.AccessibilityService.findviewEX(r, t);
		},
		zxzjd寻找节点_描述: async function(des, t) {
			t = t || 3000;
			var r = {
				contentDescriptionEX: des
			};
			return await android.AccessibilityService.findviewEX(r, t);
		},
		/**
		 * @param {Object} r 资源描述
		 * @param {Object} t	超时时间 没找到返回false
		 * @description 寻找节点 带时间
		 * @return {javascriptnode} node对象,失败返回null
		 */
		findviewEX: async function(r, t) {
			t = t || 3000;
			var node = null;
			var kst = new Date().getTime();
			while (true) {
				var findnode = this.findview(r);
				if (findnode) {
					return findnode;
				}
				var newt = new Date().getTime() - kst;
				if (newt > t) {
					return null;
				}
				await sleep(100);
			}
		},
		zxzjd寻找节点持续: async function(r, t) {
			return await this.findviewEX(r, t);
		},
		/**
		 * @description  获取通知栏节点对象 成功返回node对象   失败返回null
		 * @return {javascriptnode}
		 */
		getnotification: function() {
			var nodeid = this.className.getnotification();
			if (nodeid) {
				return new javascriptnode(nodeid, this.className);
			} else {
				return null;
			}
		},
		/**
		 * @description 打开或者关闭界面变化回调 无返回值
		 * @param {true} isopen 打开或者关闭
		 */
		opennodechange: function(isopen) {
			this.className.nodechange(isopen);
		},
		zjmbhhd界面变化回调控制: function(isopen) {
			this.className.nodechange(isopen);
		},
		/**
		 * @description  界面变化回调函数
		 * @param {Object} data  界面变化内容
		 */
		nodechange: function(data) {},
		getwindows: function() {
			let nodeids = this.className.getwindows();;
			var nodes = Array();
			if (nodeids) {
				for (var i = 0; i < nodeids.length; i++) {
					var nodeid = nodeids[i];
					nodes[i] = new javascriptnode(nodeid, this.className);
				}
				return nodes;
			} else {
				return null;
			}

		},
		zhqcksz获取窗口数组: function() {
			return this.className.getwindows();
		},
		/**
		 * @description  直线滑动
		 * @param {Object} x 开始坐标 x
		 * @param {Object} y 开始坐标y
		 * @param {Object} x1 结束坐标x
		 * @param {Object} y1 结束坐标y
		 * @param {Object} t 执行时间
		 */
		swipe: function(x, y, x1, y1, t) {
			return android.gesture.swipe(Math.trunc(x), Math.trunc(y), Math.trunc(x1), Math.trunc(y1), Math
				.trunc(t));
		},
		runpath: function(path, t) {
			return this.className.runpath(path, t);
		},
		/**
		 * @description  获取当前界面
		 */
		gettopactivity: function() {
			return this.className.gettopactivity();
		},
		zhqdq获取当前界面: function() {
			return this.className.gettopactivity();
		},
		accinputcode: function(code) {
			return this.className.accinputcode(Math.trunc(code));
		},
	},
	/**
	 * @description  java异步通知都会经过这个函数分流
	 * @param {Object} data 回调参数
	 */
	callback: async function(data) {
		data = decodeURIComponent(data);
		try {
			var obj = JSON.parse(data);
			var fun = obj.fun;
			//对回调事件进行分类处理
			switch (fun) {
				case "nodechange":
					android.AccessibilityService.nodechange(data);
					//界面变化
					break;
				case "tcp":
					//tcp消息
					break;
				case "tcpserver":
					//tcp服务器
					break;
				case "udp":
					//udp消息
					break;
				case "httpserver":
					//http服务器
					break;
				case "floatwclick":
					// 悬浮窗点击
					var isok = await android.floatwindow.onclick(data);
					if (isok) {
						//如果为真 进行默认处理
					}
					break;
				case "log":
					// java层log事件
					data = obj.data;
					android.log.log("java日志", data);
					break;
				default:
					break;
			}
		} catch (e) {
			//TODO handle the exception
		}
	}
}
window.sleep = function(ms) {
	return new Promise(function(resolve, reject) {
		setTimeout(resolve, ms);
	})
}
/**
 * @description  node对象方法
 */
function javascriptnode(id, className) {
	this.id = id;
	this.className = className;
	/**
	 * @description 节点转json 成功返回json文本 失败返回null
	 * @return {JSON}  成功返回json文本 失败返回null
	 */
	this.tojson = function() {
		return this.className.nodetojson(this.id);
	};
	/**
	 * @description   寻找单个节点  成功返回 node的javascript对象 失败返回null	
	 * @param {Object} r资源描述 
	 * @return {javascriptnode} 返回node的javascript对象 
	 */
	this.findview = function(r) {
		var newr = {};
		for (var key in r) {
			if (r[key] != null) {
				newr[key] = r[key];
			}
		}
		console.log(this.id);
		let nodeid = this.className.findview(this.id, JSON.stringify(newr));
		if (nodeid) {
			return new javascriptnode(nodeid, this.className);
		} else {
			return null;
		}
	};
	/**
	 * @description  寻找多个节点 找到了 返回 node对象数组 没找到返回null
	 * @param {node} node对象
	 * @param {r} r 资源描述
	 * @return {nodearr}  找到了 返回 node对象数组 没找到返回null
	 */
	this.findviews = function(r) {
		var newr = {};
		for (var key in r) {
			if (r[key] != null) {
				newr[key] = r[key];
			}
		}
		let nodeids = this.className.findviews(this.id, JSON.stringify(newr));
		var nodes = Array();
		if (nodeids) {
			for (var i = 0; i < nodeids.length; i++) {
				var nodeid = nodeids[i];
				nodes[i] = new javascriptnode(nodeid, this.className);
			}
			return nodes;
		} else {
			return null;
		}
	};
	/**
	 * @param {r} r 资源描述 
	 * @param {int} t	超时时间 没找到返回false
	 * @description 寻找节点 带时间 成功返回node对象,失败返回nul
	 * @return {javascriptnode} node对象,失败返回null
	 */
	this.findviewEX = async function(r, t) {
		var node = null;
		var kst = new Date().getTime();
		while (true) {
			var findnode = this.findview(r);
			if (findnode) {
				return findnode;
			}
			var newt = new Date().getTime() - kst;
			if (newt > t) {
				return null;
			}
			await sleep(100);
		}
	};
	/**
	 * @description  获取节点坐标 返回数组
	 * @param {int} index 1 左上角 2 中间  3 右下角 4  4个点
	 * @return {arr}
	 */
	this.getxy = function(index) {
		var xy = {};
		var nodejson = JSON.parse(this.tojson());
		var boundsInScreen = nodejson.boundsInScreen;
		var str = boundsInScreen.replace("Rect(", "")
		str = str.replace(")", "")
		str = str.replace("-", ",")
		var arr = str.split(",");
		for (var key in arr) {
			arr[key] = Number(arr[key]);
		}
		if (index == 1) {
			return Array(arr[0], arr[1]);
		}
		if (index == 2) {
			return Array(Math.trunc((arr[0] + arr[2]) / 2), Math.trunc((arr[1] + arr[3]) / 2));
		}
		if (index == 3) {
			return Array(arr[2], arr[3]);
		}
		return arr;
	};
	this.zhqzb获取坐标 = function(index) {
		return this.getxy(index);
	};
	/**
	 * @description  执行事件智能 会自动寻找附近可操作节点  成功返回true  失败返回false
	 * @param {int} code 事件代码
	 * @return {true} 成功返回true  失败返回false
	 */
	this.performActionEX = function(code) {
		return this.className.performActionEX(this.id, code);
	};
	this.zzxsj执行事件智能 = function(code) {
		return this.className.performActionEX(this.id, code);
	};
	/**
	 * @description  执行事件 必须可执行 成功true 失败false
	 * @param {int} code 事件代码
	 * @return {true} 成功返回true  失败返回false
	 */
	this.performAction = function(code) {
		return this.className.performAction(this.id, code);
	};
	this.zzxsj执行事件 = function(code) {
		return this.className.performAction(this.id, code);
	};
	/**
	 * @description  节点点击 普通 成功true 失败false
	 * @return {true} 成功true 失败false
	 */
	this.click = function() {
		return this.performAction(16);
	};
	this.zdj点击 = function() {
		return this.performAction(16);
	};
	/**
	 * @description  节点点击 智能 成功true 失败false
	 * @return {true} 成功true 失败false
	 */
	this.clickEX = function() {
		return this.performActionEX(16);
	};
	this.zdj点击高级 = function() {
		return this.performActionEX(16);
	};
	/**
	 * @description  节点点击 手势 成功true 失败false
	 * @return {true} 成功true 失败false
	 */
	this.clickGT = function() {
		var arrxy = this.getxy(2);
		if (arrxy) {
			android.gesture.swipe(arrxy[0], arrxy[1], arrxy[0], arrxy[1], 50);
			return true;
		}
		return false;
	};
	this.zdj点击手势 = function() {
		var arrxy = this.getxy(2);
		if (arrxy) {
			android.gesture.swipe(arrxy[0], arrxy[1], arrxy[0], arrxy[1], 50);
			return true;
		}
		return false;
	};
	/**
	 * @description  节点点击 普通 成功true 失败false
	 * @return {true} 成功true 失败false
	 */
	this.longclick = function() {
		return this.performAction(32);
	};
	this.zch长按 = function() {
		return this.performAction(32);
	};
	/**
	 * @description  节点点击 智能 成功true 失败false
	 * @return {true} 成功true 失败false
	 */
	this.langclickEX = function() {
		return this.performActionEX(32);
	};
	this.zca长按高级 = function() {
		return this.performActionEX(32);
	};
	/**
	 * @description  节点点击 手势 成功true 失败false
	 * @return {true} 成功true 失败false
	 */
	this.langclickGT = function() {
		var arrxy = this.getxy(2);
		if (arrxy) {
			android.gesture.swipe(arrxy[0], arrxy[1], arrxy[0], arrxy[1], 500);
			return true;
		}
		return false;
	};
	this.zca长按手势 = function() {
		var arrxy = this.getxy(2);
		if (arrxy) {
			android.gesture.swipe(arrxy[0], arrxy[1], arrxy[0], arrxy[1], 500);
			return true;
		}
		return false;
	};
	/**
	 * @description   节点滚动 节点 必须可以操作 成功true 失败false
	 * @param {int} index 方向 1右和 下  2 左和上 
	 * @return {true} 成功 返回true 失败返回false
	 */
	this.scroll = function(index) {
		if (index == 1) {
			return this.performAction(4096);
		} else if (index == 2) {
			return this.performAction(8192);
		}
		return false;
	};
	this.zhd滑动 = function(index) {
		if (index == 1) {
			return this.performAction(4096);
		} else if (index == 2) {
			return this.performAction(8192);
		}
		return false;
	};
	/**
	 * @description   节点滚动 智能搜索最近可 操作节点 成功true 失败false
	 * @param {int} index 方向 1右和 下  2 左和上 
	 * @return {true} 成功 返回true 失败返回false
	 */
	this.scrollEX = function(index) {
		if (index == 1) {
			return this.performActionEX(4096);
		} else if (index == 2) {
			return this.performActionEX(8192);
		}
		return false;
	}
	this.z滑动高级 = function(index) {
		if (index == 1) {
			return this.performActionEX(4096);
		} else if (index == 2) {
			return this.performActionEX(8192);
		}
		return false;
	}
	/**
	 * @description   节点滚动  手势 安卓7.0+ 距离为节点宽 高 成功true 失败false
	 * @param {int} index 方向 1 上往下  2  左往右 3 下往上  4  右向左
	 * @return {true} 成功 返回true 失败返回false
	 */
	this.scrollGT = function(index) {
		var arrxy = this.getxy(4);
		var arrzx = this.getxy(2);
		switch (index) {
			case 1:
				return android.gesture.swipe(arrzx[0], arrxy[1], arrzx[0], arrxy[3], 500);
				break;
			case 2:
				return android.gesture.swipe(arrxy[0], arrzx[1], arrxy[2], arrzx[1], 500);
				break;
			case 3:
				return android.gesture.swipe(arrzx[0], arrxy[3], arrzx[0], arrxy[1], 500);
				break;
			case 4:
				return android.gesture.swipe(arrxy[2], arrzx[1], arrxy[0], arrzx[1], 500);
				break;
			default:
				return false;
				break;
		}
		return false;
	};
	this.zhd滑动手势 = function(index) {
		var arrxy = this.getxy(4);
		var arrzx = this.getxy(2);
		switch (index) {
			case 1:
				return android.gesture.swipe(arrzx[0], arrxy[1], arrzx[0], arrxy[3], 500);
				break;
			case 2:
				return android.gesture.swipe(arrxy[0], arrzx[1], arrxy[2], arrzx[1], 500);
				break;
			case 3:
				return android.gesture.swipe(arrzx[0], arrxy[3], arrzx[0], arrxy[1], 500);
				break;
			case 4:
				return android.gesture.swipe(arrxy[2], arrzx[1], arrxy[0], arrzx[1], 500);
				break;
			default:
				return false;
				break;
		}
		return false;
	};
	/**
	 * @description  剪辑版方式输入内容 成功true 失败false
	 * @param {str} str 输入的内容 
	 */
	this.setClipText = function(str) {
		return this.className.setClipText(this.id, str);
	};
	this.zsrwb输入本文剪辑版 = function(str) {
		return this.className.setClipText(this.id, str);
	};
	/**
	 * @description  直接输入文本 成功true 失败false
	 * @param {str} str 输入的内容 
	 */
	this.setText = function(str) {
		return this.className.setText(this.id, str);
	};
	this.zsrwb输入文本直接设置 = function(str) {
		return this.className.setText(this.id, str);
	};
	/**
	 * @description   获取子节点个数 返回整数  失败返回-1
	 * @return {int} 失败返回-1
	 */
	this.getChildCount = function() {
		return this.className.getChildCount(this.id);
	}
	this.zhqzjd获取子节点数量 = function() {
		return this.className.getChildCount(this.id);
	}
	/**
	 * @description   获取子节  返回 node对象 失败返回null
	 * @param {int} index 
	 * @return {javascriptnode} node对象 失败返回null
	 */
	this.getChild = function(index) {
		var nodeid = this.className.getChild(this.id, index);
		if (nodeid) {
			return new this.constructor(nodeid, this.className);
		} else {
			return null;
		}
	};
	this.zhqzjd获取子节点 = function(index) {
		var nodeid = this.className.getChild(this.id, index);
		if (nodeid) {
			return new this.constructor(nodeid, this.className);
		} else {
			return null;
		}
	};
	/**
	 * @description   获取父节点 返回 node对象 失败返回null
	 * @return {javascriptnode} node对象 失败返回null
	 */
	this.getParent = function() {
		var nodeid = this.className.getParent(this.id);
		if (nodeid) {
			return new this.constructor(nodeid, this.className);
		} else {
			return null;
		}
	};
	this.zhqfjd获取父节点 = function() {
		var nodeid = this.className.getParent(this.id);
		if (nodeid) {
			return new this.constructor(nodeid, this.className);
		} else {
			return null;
		}
	};
	/**
	 * @description 获取节点text属性 返回文本
	 */
	this.getText = function() {
		return this.className.getText(this.id);
	};
	this.zhq获取文本 = function() {
		return this.className.getText(this.id);
	};
	/**
	 * @description 获取节点des属性 返回文本
	 */
	this.getdes = function() {
		return this.className.getdes(this.id);
	};
	this.zhq获取描述 = function() {
		return this.className.getdes(this.id);
	};
	/**
	 * @description  获取节点的原生对象 返回 java的node对象 注意释放
	 * @return {node} java的node对象 注意释放
	 */
	this.getclass = function() {
		return this.className.getclass(this.id);
	}
	/**
	 * @description 上一个节点
	 * @param {Object} resid 资源id
	 * @return {javascriptnode} node对象,失败返回null
	 */
	this.lastnode = function() {
		var nodeid = this.className.lastnode(this.id, 1);
		if (nodeid) {
			return new javascriptnode(nodeid, this.className);
		} else {
			return null;
		}
	}
	/**
	 * @description 下一个节点
	 * @param {Object} resid 资源id
	 * @return {javascriptnode} node对象,失败返回null
	 */
	this.nextnode = function() {
		var nodeid = this.className.lastnode(this.id, 2);
		if (nodeid) {
			return new javascriptnode(nodeid, this.className);
		} else {
			return null;
		}
	}
}

function javascriptbitmap(id, className) {
	this.id = id;
	this.className = className;
	/**
	 * @description  转bas e64
	 * @return {str} 图片base64文本
	 */
	this.tobase64 = function() {
		return this.className.tobase64(this.id);
	}
	/**
	 * @description  旋转图片
	 * @param {type} ori 旋转角度 
	 * @return {str} 图片base64文本
	 */
	this.rotating = function(ori) {
		var imgid = this.className.rotating(this.id, ori);
		return new javascriptbitmap(imgid, this.className);

	}
	this.zz转base64 = function() {
		return this.tobase64(this.id);
	}
	/**
	 * @description  转base64带压缩
	 * @param {int} qua清晰度,1-100,100为 原图
	 * @return {str} 图片base64文本
	 */
	this.tobase64EX = function(qua) {
		return this.className.tobase64EX(this.id, qua);
	}
	this.zz转base64带压缩 = function(qua) {
		return this.tobase64EX(this.id, qua);
	}
	/**
	 * @description 等比例缩放图片
	 * @param {Object} w  新图宽度
	 * @return {img}  新图片对象
	 */
	this.bitmapract = function(w, h) {
		var imgid = this.className.bitmapract(this.id, Math.round(w), Math.round(h));
		return new javascriptbitmap(imgid, this.className);
	}
	this.z等比例缩放图片 = function(w, h) {
		return this.bitmapract(w, h);
	}
	/**
	 * @description 保存图片
	 * @param {Object} path 路径
	 * @return {bool}
	 */
	this.save = function(path) {
		return this.className.save(this.id, path);
	}
	this.zbc保存图片 = function(path) {
		return this.save(path);
	}
	/**
	 * @description  释放图片
	 */
	this.recycle = function() {
		if (this.id == 0) {
			return;
		}
		return this.className.recycle(this.id);
	}
	/**
	 * @description 灰度化
	 * @return {javascriptbitmap}
	 */
	this.toGrayscale = function() {
		var imgid = this.className.toGrayscale(this.id);
		return new javascriptbitmap(imgid, this.className);
	}

	/**
	 * @description 灰度化
	 * @return {javascriptbitmap}
	 */
	this.thecolor = function() {
		var imgid = this.className.thecolor(this.id);
		return new javascriptbitmap(imgid, this.className);
	}
	/**
	 * @description 灰度化
	 * @return {javascriptbitmap}
	 */
	this.tomargin = function() {
		var imgid = this.className.tomargin(this.id);
		return new javascriptbitmap(imgid, this.className);
	}
	this.zhd灰度化 = function() {
		return this.toGrayscale();
	}
	/**
	 * @description 二值化
	 * @param {colorstr} colorstr 颜色
	 * @return {javascriptbitmap}
	 */
	this.graying = function() {
		var id = this.className.graying(this.id)
		return new javascriptbitmap(id, this.className);
	}
	this.zez二值化 = function() {
		return this.graying(this.id);
	}
	/**
	 * @description 去除背景
	 *@param {str} colorstr 颜色描述文本 
	 * @return {javascriptbitmap}
	 */
	this.delbackground = function(colorstr) {
		var id = this.className.delbackground(this.id, colorstr)
		return new javascriptbitmap(id, this.className);
	}
	/**
	 * @description 获取颜色数量
	 *@param {str} colorstr 颜色描述文本 
	 * @return {int}
	 */
	this.getcolorcount = function(colorstr) {
		return this.className.getcolorcount(this.id, colorstr)
	}

	this.zqc去除背景 = function(colorstr) {
		return this.delbackground(colorstr);
	}
	/**
	 * @description 区域截图
	 * @param {Object} x 起始点x
	 * @param {Object} y 起始点y
	 * @param {Object} w 宽度
	 * @param {Object} h 高度
	 * @return {javascriptbitmap}
	 */
	this.getareaimg = function(x, y, w, h) {
		var id = this.className.areaimg(this.id, x, y, w, h);
		return new javascriptbitmap(id, this.className);
	}
	this.zqy区域截图 = function(x, y, w, h) {
		return this.getareaimg(x, y, w, h);
	}
	/**
	 * @description 多点比色
	 * @param {Object} colorstr
	 */
	this.iscolors = function(colorstr, qua) {
		return this.className.iscolors(this.id, colorstr, qua);
	}
	/**
	 * @description  多点找色
	 * @param {Object} x 坐标
	 * @param {Object} y  坐标
	 * @param {Object} x2 坐标
	 * @param {Object} y2 坐标
	 * @param {Object} colorstr 颜色 描述
	 * @param {qua} 相似度
	 * @return {intarr} 坐标数组
	 */
	this.findcolors = function(x, y, x2, y2, qua, colorstr) {
		return this.className.findcolors(this.id, x, y, x2, y2, qua, colorstr);
	}
	/**
	 * @description  单点找色
	 * @param {Object} x 坐标
	 * @param {Object} y  坐标
	 * @param {Object} x2 坐标
	 * @param {Object} y2 坐标
	 * @param {Object} colorstr 颜色 描述

	 * @return {intarr} 坐标数组
	 */
	this.findcolor = function(x, y, x2, y2, colorstr) {
		return this.className.findcolor(this.id, x, y, x2, y2, colorstr);
	}
	/**
	 * @description  单点比色
	 * @param {Object} x 坐标
	 * @param {Object} y 坐标
	 * @param {bool} true false
	 */
	this.iscolor = function(x, y, colorstr) {
		return this.className.iscolor(this.id, x, y, colorstr);
	}


	this.zdd单点找色 = function(x, y, x2, y2, colorstr) {
		return this.findcolor(x, y, x2, y2, colorstr);
	}
	/**
	 * @description  寻找图片
	 * @param {str} zb  坐标描述
	 * @param {int} findimgid 
	 */
	this.findimg = function(zb, findimgid) {
		return this.className.findimg(this.id, zb, findimgid);
	}
	this.zxztp寻找图片 = function(zb, findimgid) {
		return this.findimg(zb, findimgid);
	}
	/**
	 * @description  获取指定点颜色
	 * @param {int} x
	 * @param {int} y
	 */
	this.getcolor = function(x, y) {
		return this.className.getcolor(this.id, x, y);
	}
	this.zqdys取点颜色 = function(x, y) {
		return this.getcolor(x, y);
	}
	/**
	 * @description 获取图片宽度
	 */
	this.getwidth = function() {
		return this.className.getWidth(this.id);
	}
	this.zqtpkd获取图片宽度 = function() {
		return this.getwidth();
	}
	/**
	 * @description  获取图片高度
	 */
	this.getheight = function() {
		return this.className.getHeight(this.id);
	}
	this.zqtpgd获取图片高度 = function() {
		return this.getheight();
	}
	/**
	 * @description  寻找图片
	 * @param {int}  zb 坐标描述
	 * @param {int} imgid img
	 * @param {int} ms 模式 1普通,2 去除背景 3二值化,4 灰度化
	 * @param {str} colorstr 颜色描述 
	 */
	this.findimgEX = function(zb, imgid, ms, colorstr) {
		return this.className.findimgEX(this.id, zb, imgid, ms, colorstr);
	}
	this.zxztp寻找图片EX = function(zb, imgid, ms, colorstr) {
		return this.findimgEX(zb, imgid, ms, colorstr);
	}
}
window.log = function() {};
window.err = function() {};
window.acc = android.AccessibilityService;
window.floatw = android.floatwindow;
window.screen = android.screen; //录屏对象
//全局对象初始化
window.global = android.global;
window.app = android.global;
window.file = android.fie;
//loadex初始化
window.loaddex = android.loaddex;
//http初始化
window.http = android.http;
//ocr
window.ocr = android.ocr;
//短信服务
window.sms = android.sms;
//手势服务
window.gesture = android.gesture;
//通讯录服务
window.contacts = android.contacts;
window.mysql = android.mysql;
window.zip = android.zip;
window.mon = {
	/**
	 * 
	 *@description 输入法权限申请
	 */
	getinput: function() {
		//输入法初始化
		window.input = android.input;
		if (!input.isopen()) {
			global.toast("请允许输入法权限");
			return false;
		}
		return true;
	},
	/** 
	 *@description 截图权限申请
	 */
	getscreen: function() {
		//图色初始化
		if (!screen.isopen()) {
			global.toast("请允许截图权限");
			return false;
		}
		return true;
	},
	/**
	 *@description 初始权限申请
	 */
	getauthority: async function() {
		android.device.os = plus.os;
		android.device.imei = plus.device;
		android.device.screen = plus.screen;
		global.getsever();
		//文件初始化
		file.getsever();
		loaddex.getsever();
		http.getsever();
		gesture.getsever();
		//contacts.getsever();
		//===== 重写返回键逻辑 开始========

		//====重写返回键逻辑结束=========
		await new Promise(
			function(resolve, reject) {
				plus.device.getInfo({
					success: function(e) {
						android.device.info = e;
						resolve(null);
					}
				});
			}
		);
		app.className.setdevice(JSON.stringify(android.device))
		await new Promise(
			function(resolve, reject) {
				plus.io.requestFileSystem(plus.io.PRIVATE_WWW, function(fs) {
					android.path = fs.root.fullPath;
					resolve();
				});
			}
		);
		if (acc.isopenAccessibility(false) == false) {
			accui.alert('权限检查', '没有无障碍权限,请开启', ['去开启'], function(e) {
				acc.isopenAccessibility(true);
				accui.alert('权限检查', '无障碍权限', ['下一步'], function(e) {
					setTimeout(function() {
						mon.getauthority();
					}, 100);
				}, 'div')
			}, 'div')
			return false;
		}
		floatw.getsever();
		try {
			if (!floatw.isopen()) {
				accui.alert('权限检查', '请允许悬浮窗权限', ['去开启'], function(e) {
					floatw.openseting();
					accui.alert('权限检查', '请允许悬浮窗权限', ['下一步'], function(e) {
						setTimeout(function() {
							mon.getauthority();
						}, 100);
					}, 'div')
				}, 'div')
				return false;
			}
		} catch (e) {
			//TODO handle the exception
		}
		floatw.star();
		window.accisok = true;
		mainjs();
		return true;
	},
	/**
	 * 
	 *@description 通讯录权限
	 */
	getphone: function() {
		var Build = plus.android.importClass("android.os.Build");
		var Manifest = plus.android.importClass("android.Manifest");
		var MainActivity = plus.android.runtimeMainActivity();
		//var context=main.getApplicationContext(); //未用到,在此仅供参考  
		var ArrPermissions = [
			Manifest.permission.READ_EXTERNAL_STORAGE,
			Manifest.permission.WRITE_EXTERNAL_STORAGE,
			Manifest.permission.READ_CONTACTS,
			Manifest.permission.WRITE_CONTACTS,
			Manifest.permission.GET_ACCOUNTS,
			Manifest.permission.READ_SMS
		];

		function PermissionCheck(permission) {
			if (Build.VERSION.SDK_INT >= 23) {
				if (MainActivity.checkSelfPermission(permission) == -1) {
					return false;
				}
			}
			return true;
		}

		function PermissionChecks(Arr) {
			var HasPermission = true;
			for (var index in Arr) {
				var permission = Arr[index];
				//如果此处没有权限,则是用户拒绝了  
				if (!PermissionCheck(permission)) {
					HasPermission = false;
					break;
				}
			}
			return HasPermission;
		}

		function PermissionRequest(Arr) {
			var REQUEST_CODE_CONTACT = 101;
			if (Build.VERSION.SDK_INT >= 23) {
				MainActivity.requestPermissions(Arr, REQUEST_CODE_CONTACT);
			}
		}
		//如果没有权限，则申请  
		if (!PermissionChecks(ArrPermissions)) {
			PermissionRequest(ArrPermissions);
			return false
		} else {
			return true;
		}
	}
}
window.evalcode = function(str) {
	str = decodeURIComponent(str);
	str = 'async function runcode(){try{' + str + '}catch(e){err(e)}}runcode()';
	eval(str);
};
