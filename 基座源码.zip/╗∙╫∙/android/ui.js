accui = {
	/**
	 * @description  重置所有ui
	 */
	resetui: async function() {
		document.body.innerHTML =
			'';
		//<div id="shade" class="mui-popup-backdrop mui-active" style="display: none;"></div>
	},
	/**
	 * @description  设置主题色
	 * @param {Object} color
	 */
	settheme: function(color) {
		document.querySelector(':root').setAttribute('style', '--main-color: ' + color);
	},
	/**
	 * @description 设置背景颜色
	 * @param {Object} id 按钮id
	 * @param {Object} back 颜色值
	 */
	set_background: async function(id, back) {
		if (id == null) {
			document.body.style.background = back;
		} else {
			document.getElementById(id).style.background = back;
		}
	},
	/**
	 * @description 显示隐藏控件
	 * @param {Object} id 
	 * @param {Object} show 是否显示
	 */
	set_visible: async function(id, show) {
		if (show) {
			document.getElementById(id).style.display = "none"
		} else {
			document.getElementById(id).style.display = ""
		}
	},
	ssss: {
		creatbodydiv: async function() {
			if (document.getElementById("acc_body") == null) {
				var div = document.createElement('div');
				div.id = "acc_body";

				div.style.height="85%"
			
				div.style.overflowY="auto"

				var bo = document.body;
				bo.insertBefore(div, bo.lastChild);
			}
		}
	},
	/**
	 * @description  创建标题
	 * @param {Object} str 标题名字
	 */
	creat_title: async function(str) {
		if (document.getElementById("acc_title") == null) {
			var div = document.createElement('header');
			div.id = "acc_title"
			div.className = "accui-bar";
		
			div.innerHTML = `<h1 class="accui-title">${str}</h1>`;
			var bo = document.body;
			bo.insertBefore(div, bo.lastChild);

			var div = document.createElement('div');
			div.id = "acc_title_div"
			div.className = "accui-title-div";
			div.style.height="5%"
			var bo = document.body;
			bo.insertBefore(div, bo.lastChild);

		} else {
			document.getElementById("acc_title").innerHTML = `<h1 class="accui-title">${str}</h1>`;
		}

	},
	set_title_txt: async function(txt) {
		document.getElementsByClassName("accui-title")[0].innerText = txt;
	},
	/**
	 * @description 创建单选开关
	 * @param {Object} id id
	 * @param {Object} text 标签名字
	 * @param {Object} isopen 默认打开关闭
	 * @param {Object} change 点击回调
	 */
	creat_swith: async function(id, text, isopen, change) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input";
			//<label class="fixed-w" style="width: 8em;">11111</label>
			var label = document.createElement('label');
			label.innerText = text;
			label.style.width = "auto"

			var div2 = document.createElement('div');
			div2.onclick = function() {

				var isswith = accui.is_swith(id);
				accui.set_swith(id, !isswith)
				if (change) {
					change(id, !isswith);
				}
			}
			if (isopen) {
				div2.className = "accui-swith-wrap   lcs_switch lcs_on  lcs_checkbox_switch ";
			} else {
				div2.className = "accui-swith-wrap   lcs_switch lcs_off  lcs_checkbox_switch ";
			}
			div2.innerHTML =
				`<div class="lcs_cursor"></div>
					<div class="lcs_label lcs_label_on">ON</div>
					<div class="lcs_label lcs_label_off">OFF</div>`;
			div.insertBefore(label, div.lastChild);
			div.insertBefore(div2, div.lastChild);
			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}
	},
	/**
	 * @description  获取单选是否打开
	 * @return {bool} 是否打开
	 * @param {Object} id 
	 */
	is_swith: function(id) {
		return document.getElementById(id).childNodes[0].classList.contains('lcs_on');
	},
	/**
	 * @description 设置单选
	 * @param {Object} id
	 * @param {Object} isswith 是否选中
	 */
	set_swith: async function(id, isswith) {
		if (isswith) {
			document.getElementById(id).childNodes[0].className =
				"accui-swith-wrap   lcs_switch lcs_on  lcs_checkbox_switch "
		} else {
			document.getElementById(id).childNodes[0].className =
				"accui-swith-wrap   lcs_switch lcs_off  lcs_checkbox_switch "
		}
	},
	/**
	 * @description  创建输入框
	 * @param {Object} id
	 * @param {Object} name
	 * @param {Object} des
	 * @param {Object} value
	 */
	creat_input: async function(id, name, des, value, pwd) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input";
			var label = document.createElement('label');
			label.innerText = name;
			label.className = "fixed-w";
			label.style.width = "6em"
			var div2 = document.createElement('input');
			div2.className = "accui-input";
			if (pwd) {
				div2.type = "password"
			} else {
				div2.type = "text"
			}
			div2.placeholder = des
			if (value.length > 0) {
				div2.value = value;
			}
			div.insertBefore(label, null);
			div.insertBefore(div2, null);


			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}
	},
	/**
	 * @description  获取输入框值
	 * @param {Object} id
	 */
	get_input: function(id) {
		return document.getElementById(id).childNodes[1].value;
	},
	/**
	 * @description  更改输入框值
	 * @param {Object} id
	 * @param {txt} txt 值 
	 */
	set_input_txt: async function(id, txt) {
		document.getElementById(id).childNodes[1].value = txt;
	},
	/**
	 * @description  创建多行输入框
	 * @param {Object} id
	 * @param {Object} name
	 * @param {Object} des
	 * @param {Object} value
	 */
	creat_input_more: async function(id, name, des, value) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input";
			var label = document.createElement('label');
			label.innerText = name;
			label.className = "fixed-w";
			label.style.width = "6em"
			var div2 = document.createElement('textarea');
			div2.className = "accui-textarea";
			div2.type = "text"
			div2.placeholder = des
			if (value.length > 0) {
				div2.value = value;
			}

			div.insertBefore(label, null);
			div.insertBefore(div2, null);


			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}
	},

	/**
	 * @description  创建多选框
	 * @param {Object} id
	 * @param {Object} title 标题数组
	 * @param {Object} change 电击回调
	 */
	creat_checkbox: async function(id, title, change) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input";
			var len = title.length;
			var clen = 90 / len;
			for (var i = 0; i < len; i++) {
				var childdiv = document.createElement('div');
				childdiv.style.width = clen + "%"
				childdiv.innerHTML =
					`<label class="accui-checkbox icon-font i-tick"
						style="width: 20px;height: 20px;color:#00e100; "></label><label class="fixed-w"
						style="margin-left: 10px; padding-left: 20px;">${title[i]}</label>`

				childdiv.onclick = async function() {
					console.log(this);
					var ischeck = (this.childNodes[0].className ==
						"accui-checkbox icon-font i-tick");
					if (ischeck) {
						this.childNodes[0].className = "accui-checkbox "

					} else {
						this.childNodes[0].className = "accui-checkbox icon-font i-tick"
					}
					if (change) {
						await change(this.childNodes[1].innerText, !ischeck)
					}
				}

				div.insertBefore(childdiv, null);
			}
			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}
	},

	/**
	 * @description 获取多选框是否选中
	 * @param {Object} id
	 * @param {Object} index 第几个
	 */
	get_checkbox: function(id, index) {
		return document.getElementById(id).childNodes[index].childNodes[0].className ==
			"accui-checkbox icon-font i-tick";
	},
	/**
	 * @description 设置多选框是否选中 
	 * @param {Object} id 
	 * @param {Object} index 第几个
	 * @param {Object} checks 选中
	 */
	set_checkbox: async function(id, index, check) {
		if (check) {
			document.getElementById(id).childNodes[index].childNodes[0].className =
				"accui-checkbox icon-font i-tick";
		} else {
			document.getElementById(id).childNodes[index].childNodes[0].className = "accui-checkbox";
		}

	},
	/**
	 * @description 创建下拉列表框
	 * @param {Object} id
	 * @param {Object} name 名字
	 * @param {Object} title 选择数组
	 * @param {obj}  onchange 变化回调 
	 */
	creat_option: async function(id, name, title, onchange) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input";

			var label = document.createElement('label');
			label.innerText = name;
			label.className = "fixed-w";
			label.style.width = "6em"
			div.insertBefore(label, null);

			var len = title.length;
			var clen = 90 / len;
			var childdiv = document.createElement('select');
			if (onchange) {
				childdiv.onchange = async function() {
					await onchange(this.value);
				}
			}

			childdiv.style = "width: 70%;height:30px;  border: 1px solid #cccccc;padding-left: 20px;"


			var html = "";
			for (var i = 0; i < len; i++) {
				html = html + `<option>${title[i]}</option>`
			}

			childdiv.innerHTML = html;
			div.insertBefore(childdiv, null);
			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}
	},
	/**
	 * @description 获取当前选择
	 * @param {Object} id
	 */
	get_option: function(id) {
		return document.getElementById(id).childNodes[1].value;
	},
	/**
	 * @description 设置当前选择 
	 * @param {Object} id 
	 * @param {Object} txt 内容
	 */
	set_option: async function(id, txt) {
		document.getElementById(id).childNodes[1].value = txt;

	},
	/**
	 * @description  创建按钮
	 * @param {Object} id
	 * @param {Object} name 名字
	 * @param {Object} onclick 回调
	 */
	creat_btn: async function(id, name, onclick) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input btn-groups";
			if (onclick) {
				div.onclick = async function() {
					await onclick(this.id, this.childNodes[0].innerText);
				}
			}
			div.innerHTML = '<button type="button">' + name + '</button>';
			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}

	},
	/**
	 * @description  创建按钮
	 * @param {Object} id
	 * @param {Object} name 名字
	 * @param {Object} onclick 回调
	 */
	creat_btn: async function(id, name, onclick) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input btn-groups";
			if (onclick) {
				div.onclick = async function() {
					await onclick(this.id, this.childNodes[0].innerText);
				}
			}
			div.innerHTML = '<button type="button">' + name + '</button>';
			var bo = document.getElementById("acc_body");
			bo.insertBefore(div, null);
		}
	
	},
	
	
	
	/**
	 * @description  更改按钮文本
	 * @param {Object} id
	 * @param {Object} txt 文本
	 */
	set_btn_txt: async function(id, txt) {
		document.getElementById(id).childNodes[0].innerText = txt;
	},
	/**
	 * @description  设置按钮是否可以点击
	 * @param {Object} id
	 * @param {Object} disabled TRUE 
	 */
	set_btn_disabled: async function(id,disabled ) {
		document.getElementById(id).childNodes[0].disabled=disabled;
	},
	
	/**
	 * @description  获取按钮文本
	 * @param {Object} id
	 * @param {Object} txt 文本
	 */
	get_btn_txt: function(id, txt) {
		return document.getElementById(id).childNodes[0].innerText 
	},
	/**
	 * @description  创建底部按钮
	 * @param {Object} id
	 * @param {Object} name 名字
	 * @param {Object} onclick 点击回调
	 */
	creat_btn_nav: async function(id, name, onclick) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var nav = document.createElement('div');
			nav.className = "mui-bar mui-bar-tab";
			var div = document.createElement('div');
			div.id = id
			div.className = "inner-input btn-groups";
			if (onclick) {
				div.onclick = async function() {
					await onclick(this.id, this.childNodes[0].innerText);
				}
			}
			div.innerHTML = '<button type="button">' + name + '</button>';
			nav.insertBefore(div, null);
			var bo = document.getElementById("acc_body");
			bo.insertBefore(nav, null);
		}

	},

	/**
	 * @description  更改按钮文本
	 * @param {Object} id
	 * @param {Object} txt 文本
	 */
	set_btn_nav_txt: async function(id, txt) {
		document.getElementById(id).childNodes[0].childNodes[0].innerText = txt;
	},

	/**
	 * @description  创建底部按钮
	 * @param {Object} id
	 * @param {Object} title 名字数组
	 * @param {Object} onclick 点击回调
	 */
	creat_option_nav: async function(id, title, onclick) {
		accui.ssss.creatbodydiv();
		if (document.getElementById(id) == null) {
			var nav = document.createElement('nav');
			nav.className = "mui-bar mui-bar-tab";
			nav.id = id
			for (var i = 0; i < title.length; i++) {
				var txt = title[i];
				var a = document.createElement('a');
				a.className = "mui-tab-item mui-active";
				a.innerHTML = `<span class="mui-icon icon-font i-home"></span>
						<span class="mui-tab-label">${txt}</span>`
				if (onclick) {
					a.onclick = async function() {
						onclick(this.innerText)
					}
				}

				nav.insertBefore(a, null);

			}


			var bo = document.getElementById("acc_body");
			bo.insertBefore(nav, null);
		}

	},

	set_option_nav_icon: function(id, index,icon) {
		document.getElementById(id).childNodes[index].childNodes[0].className = "mui-icon " + icon;
	},

	/**
	 * @description  弹窗
	 * @param {Object} title 标题
	 * @param {Object} body 内容
	 * @param {Object} btns 按钮数组
	 * @param {Object} onclick 回调
	 */
	alert: function(title, body, btns, onclick) {



		accui.ssss.creatbodydiv();


		var pdiv = document.createElement('div');
		pdiv.className = "mui-popup-backdrop mui-active";


		var div = document.createElement('div');
		div.className = "mui-popup mui-popup-in";
		div.style.display = "block;"
		var div2 = document.createElement('div');
		div2.className = "mui-popup-inner";
		var divtitle = document.createElement('div');
		divtitle.className = "mui-popup-title";
		divtitle.innerText = title;
		var divbody = document.createElement('div');
		divbody.className = "mui-popup-text";
		divbody.innerText = body;
		div2.insertBefore(divtitle, null);
		div2.insertBefore(divbody, null);
		div.insertBefore(div2, null);
		if (btns.length == 1) {
			var divbt = document.createElement('span');
			divbt.className = "mui-popup-button";
			divbt.innerText = btns[0];
			div.insertBefore(divbt, null);
			divbt.onclick = function() {

				document.body.removeChild(div);

				document.body.removeChild(pdiv);

				if (onclick) {
					onclick(this.innerText);
				}
			}


		} else {
			var divbt = document.createElement('div');
			divbt.className = "mui-popup-buttons";
			div.insertBefore(divbt, null);


			for (var i = 0; i < btns.length; i++) {
				var divspan = document.createElement('span');
				divspan.className = "mui-popup-button";
				divspan.innerText = btns[i];
				divspan.onclick = function() {

					document.body.removeChild(div);
					document.body.removeChild(pdiv);
					if (onclick) {
						onclick(this.innerText);
					}
				}
				divbt.insertBefore(divspan, null);
			}
		}
		document.body.insertBefore(div, null);
		document.body.insertBefore(pdiv, null);
	}

}
async function aa() {
	accui.resetui();
	accui.setbackground(null, "#FFFFFF")
	accui.title.creat("你好ACC");



}
window.onload = function() {
	//aa();
}



const h5log = {
	arrhtml: [],
	/**
	 * @description  头
	 */
	title: "",
	/**
	 * @description  记录长度
	 */
	len: 20,
	err: ['错误', "失败"],
	/**
	 * @description   添加文字
	 * @param {Object} title 标题
	 * @param {Object} str 文本
	 */
	addlog: function(title, str) {
		//标题
		var title = `<span style="color: yellow;">【${title}】</span>`;

		//如果包含特别字符串 特别颜色
		var iserr = false;
		for (var i = 0; i < this.err.length; i++) {
			if (str.indexOf(this.err[i]) > -1) {
				iserr = true;
				break;
			}
		}
		if (iserr) {
			str = `<span style="color: red;">${str}</span>`;
		} else {
			str = `<span style="color: lime;">${str}</span>`;
		}
		this.arrhtml.push(title + str + '<br />');
		//删除超过一定长度字符串
		if (this.arrhtml.length > this.len) {
			this.arrhtml.shift();
		}
		var html = this.arrhtml.join("");
		if (this.title) {
			html = this.title + " " + html;
		}
		//这里 可以对 html加内容 作为末尾固定显示  和头一样
		floatw.addloghtml(html);
	}
}



/**
 * @description 界面ui
 */
window.ui = {
	/**
	 * @param {String} id 控件的id,不能数字和特殊符号开头
	 * @description  获取switcht状态
	 */
	getswitcht: function(id) {
		var isActive = document.getElementById(id).classList.contains("mui-active");
		return isActive;
	},


	/**
	 * @param {String} id 控件的id,不能数字和特殊符号开头
	 * @param {String} name 控件显示的名字
	 * @param {String} des 控件描述信息
	 * @param {String} value 控件默认值  
	 * @description 创建多行文本
	 */
	creatinputrow: function(id, name, des, value) {
		var div = document.createElement('div');

		div.className = "mui-card";
		div.innerHTML = '<span>' + name +
			'</span><div class="mui-input-row" style="margin: 10px 5px;"><textarea id="' + id +
			'" rows="5" placeholder="' +
			des + '">' + value + '</textarea></div>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);
	},

	/**
	 * @param {String} id 控件的id,不能数字和特殊符号开头
	 * @param {String} name 控件显示的名字
	 * @param {String} des 控件描述信息
	 * @param {String} value 控件默认值  
	 * @description 创建输入框
	 */
	creatinput: function(id, name, des, value) {




		var div = document.createElement('div');

		div.className = "mui-card";
		div.innerHTML = '<div class="mui-input-row"><label>' +
			name +
			'</label><input id="' + id + '" type="text" class="mui-input-clear" placeholder="' + des +
			'" value="' + value +
			'"></div>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);

	},
	/**
	 * @param {String} id 控件的id,不能数字和特殊符号开头
	 * @param {String} name 控件显示的名字
	 * @param {Boolean} open 是否默认开启
	 * @param {type} onclick 事件回调函数
	 * @description 创建选择框
	 */
	creatswitcht: function(id, name, open, onclick) {

		var div = document.createElement('div');

		div.className = "mui-card mui-table-view-cell";

		if (open) {
			html = '<span>' + name + '</span><div id="' + id +
				'" class="mui-switch mui-active" onclick="' + onclick +
				'"><div class="mui-switch-handle"></div></div>';
		} else {
			html = '<span>' + name + '</span><div id="' + id +
				'" class="mui-switch " onclick="' + onclick + '" ><div class="mui-switch-handle"></div></div>';
		}

		div.innerHTML = html;
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);

	},

	/**



	 * @description 监听switcht
	 */
	setswitcht: function() {
		mui('.mui-switch')['switch']();
	},

	/**
	 * @param {String} id 控件的id,不能数字和特殊符号开头
	 * @param {String} name 控件显示的名字
	 * @param {fun} onclick 点击事件响应函数
	 * @description 创建按钮
	 */
	creatbt: function(id, name, onclick) {


		var div = document.createElement('div');

		div.className = "mui-card";
		div.innerHTML = '<button style="padding: 5px  20px ; top:5px" id="' + id +
			'" type="button"  onclick="' + onclick + '" class="mui-btn mui-btn-success mui-btn-block">' + name +
			'</button>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);



	},
	/**
	 * @param {String} id 控件的id,不能数字和特殊符号开头
	 * @param {String} name 控件显示的名字
	 * @param {fun} onclick 点击事件响应函数
	 * @description 创建底部按钮
	 */
	creatbtnav: function(id, name, onclick) {

		var div = document.createElement('div');

		div.className = "mui-card";
		div.innerHTML = '<div class="mui-bar mui-bar-tab"><button style="padding: 5px  20px ; top:5px" id="' +
			id +
			'" type="button"  onclick="' + onclick + '" class="mui-btn mui-btn-success mui-btn-block">' + name +
			'</button></div>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);

	},




	/**
		 * @param {String} id 控件的id,不能数字和特殊符号开头
	
		 * @description 获取选择控件是否选中
		 * @return {boolean} 开启返回true 关闭返回false 控件id错误返回null
		 */
	getswitcht: function(id) {
		var doc = document.getElementById(id);
		if (doc == null) {
			console.log("控件id不存在");
			return null;
		}
		return doc.classList.contains("mui-active");

	},
	/**
		 * @param {String} id 控件的id,不能数字和特殊符号开头
		  * @param {String} name 名称
		 * @param {String} arrbt 数组,控件名字
		 *  @param {String} back 点击后的回调
		 * @description 创建操作表
	
	 */
	creatparent: function(id, name, arrbt, back) {


		var div = document.createElement('div');
		div.id = id;

		div.className = "mui-popover mui-popover-action mui-popover-bottom";
		var html = '<ul class="mui-table-view">';
		for (var i = 0; i < arrbt.length; i++) {
			html = html + '<li class="mui-table-view-cell"><a href="#" onclick="' + back + '">' + arrbt[i] +
				'</a></li>';

		}
		html = html + '<li class="mui-table-view-cell"><a href="#' + id +
			'"><b>取消</b></a></li></ul>';

		div.innerHTML = html;
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);
		var div = document.createElement('div');
		div.className = "mui-card mui-table-view-cell";
		div.innerHTML = '	<a class="mui-navigate-right"  href="#' +
			id + '"><span class="mui-badge">更多 </span><span>' + name + '</span></a>';
		bo.insertBefore(div, bo.lastChild);



	},

	/**
	 * @param {String} name 名称
	 * @description 创建头部	
	 */
	creattitle: function(name) {
		var div = document.createElement('header');

		div.className = "mui-bar mui-bar-nav";
		div.innerHTML = '<h1 class="mui-title" id="title">' + name + '</h1>';
		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);


		var div = document.createElement('div');

		div.className = "mui-content";

		var bo = document.body;
		bo.insertBefore(div, bo.lastChild);

	},


	creatimg: function(id, base64img) {
		//var html =<canvas id="myCanvas">你的浏览器不支持 HTML5 canvas 标签。</canvas>
		var div = document.getElementById(id);
		if (div == null) {
			var div = document.createElement('div');
			div.id = id;
			div.className = "mui-card";
			var bo = document.body;
			bo.insertBefore(div, bo.lastChild);

		}

		div.innerHTML = '<img src="' + base64img + '" />';
	},
	creatcolor: function(id, color) {
		//var html =<canvas id="myCanvas">你的浏览器不支持 HTML5 canvas 标签。</canvas>
		var div = document.getElementById(id);
		if (div == null) {
			var div = document.createElement('div');
			div.id = id;
			div.className = "mui-card";
			var bo = document.body;
			bo.insertBefore(div, bo.lastChild);

		}
		var a = pixel >> 24 & 0xff;
		var r = pixel >> 16 & 0xff;
		var g = pixel >> 8 & 0xff;
		var b = pixel & 0xff;
		div.innerText = "   ";
		div.style.background = "#" + r.toString(16) + g.toString(16) + b.toString(16);
	}
}
