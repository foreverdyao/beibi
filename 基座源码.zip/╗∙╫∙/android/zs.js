tcpzs = {
	className: null,
	connect: function(ip, port) {
		this.className.connect(ip, port)
	},
	onconnect:function(){
		log("链接")
	},
	onclose:function(){
		log("断开")
	},
	setudp: function(issend) {
		this.className.setudp(issend);
	},
	getdata: async function(data) {
		var json={};
		try {
			var data = decodeURIComponent(data);
			var json = JSON.parse(data);
			var fun = json.fun;
			var data = json.data;
			var back = json.back;
			if (fun == "eval") {
				var ml = decodeURIComponent(data);
				json.code = 0;
				json.data = ml;
				ml = "async function 远程命令(rjson){try {var returns=''; " + ml +
					";rjson.returns=returns;tcpzs.send(JSON.stringify(rjson))} catch (e) {rjson.code = -1;rjson.returns=e;tcpzs.send(JSON.stringify(rjson));}};远程命令(json);";
				//console.log(ml);
				eval(ml);
			}
		} catch (e) {
			//TODO handle the exception
			json.code = -1;
			json.returns = " 执行命令错误:" + e;
			this.send(JSON.stringify(json));
		}
	},
	send: async function(data) {
		var str = data;
		//js 和java交互 参数有长度限制  对于很大的数据 分批传值
		for (var i = 0; i < Math.ceil(str.length / 5000); i++) {
			this.className.setstr(str.substring(i * 5000, i * 5000 + 5000));
		}
		this.className.sendstr();
	},
	opentouping: function(qua, t, imgw) {
		this.className.opentouping(qua, t, imgw)
	},
	closetouping: function() {
		this.className.closetouping()
	},
	getimg: async function() {
		this.className.getimg();
	},
	sendself: async function(data) {
		var rjson = {};
		rjson.fun = "self";
		rjson.code = 0;
		rjson.returns = data;
		str = JSON.stringify(rjson);
		//js 和java交互 参数有长度限制  对于很大的数据 分批传值
		for (var i = 0; i < Math.ceil(str.length / 5000); i++) {
			this.className.setstr(str.substring(i * 5000, i * 5000 + 5000));
		}
		this.className.sendstr();
	},


}
wszs = {
	ws: null,
	isconnect: false, //是否开启自动连接
	xt: 0, //心跳
	ip: null,
	open: function(ip) {
		this.close();
		var url = "ws://" + ip
		this.ws = new WebSocket(url);
		this.ws.onopen = function() {
			global.toast("ws连接成功");
		};
		this.ws.onmessage = function(evt) {
			var received_msg = evt.data;
			//console.log("收到数据" + received_msg);
			wszs.getdata(received_msg);
		};
		this.ws.onclose = function() {
			global.toast("ws断开");

			//qd.innerText = "连接";
		};
		this.ws.onerror = function(data) {

			global.toast("ws错误");

		}
		this.ip = ip;
		if (this.xt == 0) {
			this.xt = setInterval(function() {
				//心跳包
				if (wszs.isconnect) {
					if (wszs.ws.readyState != 1) {
						global.toast("连接断开,开始自动重连" + ip);
						wszs.open(ip);
					}
					try {
						wszs.ws.send("心跳");
					} catch (e) {
						console.log(e);
					}

				}
			}, 10000)
		}

	},
	close: function() {
		try {
			this.ws.close();
		} catch (e) {
			//TODO handle the exception
		}
	},
	getdata: async function(data) {
		var json;
		try {
			json = JSON.parse(data);
			var fun = json.fun;
			var data = json.data;
			var back = json.back;
			if (fun == "eval") {
				var ml = decodeURIComponent(atob(data));
				json.code = 0;
				json.data = ml;
				ml = "async function 远程命令(rjson){try {var returns=''; " + ml +
					";rjson.returns=returns;zs.send(JSON.stringify(rjson))} catch (e) {rjson.code = -1;rjson.returns ='执行命令错误:' + e;zs.send(JSON.stringify(rjson));}};远程命令(json);";
				//console.log(ml);
				eval(ml);
			}
		} catch (e) {
			//TODO handle the exceptionvb 
			json.code = -1;
			json.returns = " 执行命令错误:" + e;
			this.send(JSON.stringify(json));
		}
	},

	send: function(str) {
		if (this.ws) {
			this.ws.send(str);
		}
	},



}
